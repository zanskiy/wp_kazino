<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_Referral {

    const BONUS_REFERRER = 5.00;  // BYN bonus to referrer on first deposit
    const BONUS_INVITED  = 2.00;  // BYN bonus to invited user on first deposit

    /* ── Generate unique code ──────────────────────────────────────────────── */
    public static function get_or_create_code( $user_id ) {
        $code = get_user_meta( $user_id, 'g24_ref_code', true );
        if ( ! $code ) {
            $code = strtoupper( substr( md5( $user_id . AUTH_KEY ), 0, 8 ) );
            update_user_meta( $user_id, 'g24_ref_code', $code );
        }
        return $code;
    }

    /* ── Get referral link ─────────────────────────────────────────────────── */
    public static function get_link( $user_id ) {
        $code = self::get_or_create_code( $user_id );
        $reg  = wp_registration_url();
        return add_query_arg( 'ref', $code, $reg );
    }

    /* ── Register referral on new user registration ────────────────────────── */
    public static function handle_registration( $user_id ) {
        if ( isset( $_COOKIE['g24_ref'] ) ) {
            $code = sanitize_text_field( $_COOKIE['g24_ref'] );
            self::link_referral( $user_id, $code );
        }
    }

    public static function link_referral( $new_user_id, $code ) {
        // Find referrer
        global $wpdb;
        $referrer_id = $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='g24_ref_code' AND meta_value=%s LIMIT 1",
            $code
        ) );
        if ( ! $referrer_id || $referrer_id == $new_user_id ) return;
        update_user_meta( $new_user_id, 'g24_referred_by', $referrer_id );
        update_user_meta( $new_user_id, 'g24_ref_bonus_given', 0 );
    }

    /* ── Give bonuses on first deposit ────────────────────────────────────── */
    public static function maybe_give_bonus( $user_id ) {
        $given = get_user_meta( $user_id, 'g24_ref_bonus_given', true );
        if ( $given ) return; // already given
        $referrer_id = get_user_meta( $user_id, 'g24_referred_by', true );
        if ( ! $referrer_id ) return;

        // Bonus to invited user
        G24_Balance::add_funds( $user_id, self::BONUS_INVITED, 'Бонус за регистрацию по приглашению' );
        // Bonus to referrer
        G24_Balance::add_funds( $referrer_id, self::BONUS_REFERRER, 'Бонус за приглашённого игрока' );

        update_user_meta( $user_id, 'g24_ref_bonus_given', 1 );

        // Track referral count for referrer
        $count = (int) get_user_meta( $referrer_id, 'g24_referrals_count', true );
        update_user_meta( $referrer_id, 'g24_referrals_count', $count + 1 );
    }

    /* ── Get stats for current user ────────────────────────────────────────── */
    public static function get_stats( $user_id ) {
        global $wpdb;
        $code  = self::get_or_create_code( $user_id );
        $count = (int) get_user_meta( $user_id, 'g24_referrals_count', true );
        $earned = $count * self::BONUS_REFERRER;
        return compact( 'code', 'count', 'earned' );
    }

    /* ── Store ?ref= param in cookie before WordPress registration ─────────── */
    public static function store_ref_cookie() {
        if ( isset( $_GET['ref'] ) && ! isset( $_COOKIE['g24_ref'] ) ) {
            setcookie( 'g24_ref', sanitize_text_field( $_GET['ref'] ), time() + 60*60*24*30, '/' );
        }
    }
}
