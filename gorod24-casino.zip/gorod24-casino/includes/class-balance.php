<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_Balance {

    public static function get_balance( $user_id ) {
        $balance = get_user_meta( $user_id, 'g24_casino_balance', true );
        return $balance !== '' ? (float) $balance : 0.00;
    }

    public static function set_balance( $user_id, $amount ) {
        update_user_meta( $user_id, 'g24_casino_balance', round( (float) $amount, 2 ) );
    }

    public static function add_funds( $user_id, $amount, $description = '' ) {
        $amount = abs( (float) $amount );
        if ( $amount <= 0 ) return false;

        $before = self::get_balance( $user_id );
        $after  = $before + $amount;
        self::set_balance( $user_id, $after );
        self::log_transaction( $user_id, 'deposit', $amount, $before, $after, $description );
        return $after;
    }

    public static function deduct_funds( $user_id, $amount, $description = '' ) {
        $amount  = abs( (float) $amount );
        $balance = self::get_balance( $user_id );
        if ( $amount <= 0 || $balance < $amount ) return false;

        $before = $balance;
        $after  = $balance - $amount;
        self::set_balance( $user_id, $after );
        self::log_transaction( $user_id, 'debit', $amount, $before, $after, $description );
        return $after;
    }

    public static function credit_winnings( $user_id, $amount, $description = '' ) {
        $amount = abs( (float) $amount );
        if ( $amount <= 0 ) return false;

        $before = self::get_balance( $user_id );
        $after  = $before + $amount;
        self::set_balance( $user_id, $after );
        self::log_transaction( $user_id, 'win', $amount, $before, $after, $description );
        return $after;
    }

    public static function log_transaction( $user_id, $type, $amount, $before, $after, $description = '' ) {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'g24_transactions',
            [
                'user_id'        => $user_id,
                'type'           => $type,
                'amount'         => $amount,
                'balance_before' => $before,
                'balance_after'  => $after,
                'description'    => $description,
                'created_at'     => current_time( 'mysql' ),
            ],
            [ '%d', '%s', '%f', '%f', '%f', '%s', '%s' ]
        );
    }

    public static function get_transactions( $user_id, $limit = 20 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_transactions WHERE user_id = %d ORDER BY created_at DESC LIMIT %d",
            $user_id, $limit
        ) );
    }

    public static function get_all_balances() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT u.ID, u.display_name, u.user_email,
                COALESCE(um.meta_value, 0) as balance
             FROM {$wpdb->users} u
             LEFT JOIN {$wpdb->usermeta} um
                ON u.ID = um.user_id AND um.meta_key = 'g24_casino_balance'
             ORDER BY balance DESC"
        );
    }
}
