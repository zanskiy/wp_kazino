<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ——— Security helpers ——— */
function g24_check_user() {
    if ( ! is_user_logged_in() ) wp_send_json_error( ['message'=>'Необходимо авторизоваться'] );
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'],'g24_casino_nonce') ) wp_send_json_error( ['message'=>'Ошибка безопасности'] );
}
function g24_check_admin() {
    if ( ! current_user_can('manage_options') ) wp_send_json_error( ['message'=>'Нет прав'] );
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'],'g24_admin_nonce') ) wp_send_json_error( ['message'=>'Ошибка безопасности'] );
}

/* ——— ROULETTE spin ——— */
add_action( 'wp_ajax_g24_spin', function() {
    g24_check_user();
    $uid   = get_current_user_id();
    $bet   = sanitize_text_field( $_POST['bet_amount'] ?? 0 );
    $type  = sanitize_text_field( $_POST['bet_type']   ?? '' );
    $value = sanitize_text_field( $_POST['bet_value']  ?? '' );
    $allowed = ['number','color','parity','half','dozen','column'];
    if ( ! in_array($type,$allowed,true) ) wp_send_json_error(['message'=>'Неверный тип ставки']);
    $result = G24_Roulette::place_bet($uid,$bet,$type,$value);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success($result);
} );

/* ——— SLOTS spin ——— */
add_action( 'wp_ajax_g24_slots_spin', function() {
    g24_check_user();
    $result = G24_Slots::spin( get_current_user_id(), floatval($_POST['bet_amount']??0) );
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success($result);
} );

/* ——— SEA BATTLE: start ——— */
add_action( 'wp_ajax_g24_seabattle_start', function() {
    g24_check_user();
    $uid = get_current_user_id();
    $result = G24_SeaBattle::start_game($uid, floatval($_POST['bet_amount']??0));
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    $result['new_balance'] = G24_Balance::get_balance($uid);
    wp_send_json_success($result);
} );

/* ——— SEA BATTLE: shoot ——— */
add_action( 'wp_ajax_g24_seabattle_shoot', function() {
    g24_check_user();
    $row = intval($_POST['row']??-1); $col = intval($_POST['col']??-1);
    if ($row<0||$row>9||$col<0||$col>9) wp_send_json_error(['message'=>'Неверные координаты']);
    $result = G24_SeaBattle::shoot(get_current_user_id(),$row,$col);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success($result);
} );

/* ——— SEA BATTLE: surrender ——— */
add_action( 'wp_ajax_g24_seabattle_surrender', function() {
    g24_check_user();
    $result = G24_SeaBattle::surrender(get_current_user_id());
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success($result);
} );

/* ——— Get balance ——— */
add_action( 'wp_ajax_g24_get_balance', function() {
    g24_check_user();
    wp_send_json_success(['balance'=>G24_Balance::get_balance(get_current_user_id())]);
} );

/* ——— Request withdrawal ——— */
add_action( 'wp_ajax_g24_request_withdrawal', function() {
    g24_check_user();
    $uid     = get_current_user_id();
    $amount  = (float) sanitize_text_field($_POST['amount']??0);
    $details = sanitize_textarea_field($_POST['card_details']??'');
    if ( empty($details) ) wp_send_json_error(['message'=>'Укажите реквизиты карты']);
    $result = G24_Withdrawals::create_request($uid,$amount,$details);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success($result);
} );

/* ——— Deposit request (user notifies admin of payment) ——— */
add_action( 'wp_ajax_g24_deposit_request', function() {
    g24_check_user();
    $uid    = get_current_user_id();
    $amount = (float) sanitize_text_field($_POST['amount']??0);
    $info   = sanitize_text_field($_POST['payment_info']??'');
    $result = G24_Deposits::create_request($uid,$amount,$info);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success(['message'=>'Заявка отправлена! Баланс будет пополнен после проверки платежа.']);
} );

/* ——— Admin: add funds ——— */
add_action( 'wp_ajax_g24_admin_add_funds', function() {
    g24_check_admin();
    $uid    = (int)($_POST['target_user_id']??0);
    $amount = (float)sanitize_text_field($_POST['amount']??0);
    $desc   = sanitize_text_field($_POST['description']??'Пополнение администратором');
    if (!$uid||$amount<=0) wp_send_json_error(['message'=>'Неверные данные']);
    $new = G24_Balance::add_funds($uid,$amount,$desc);
    if ($new===false) wp_send_json_error(['message'=>'Ошибка пополнения']);
    wp_send_json_success(['message'=>"Баланс пополнен на {$amount} BYN",'new_balance'=>$new]);
} );

/* ——— Admin: deduct funds ——— */
add_action( 'wp_ajax_g24_admin_deduct_funds', function() {
    g24_check_admin();
    $uid    = (int)($_POST['target_user_id']??0);
    $amount = (float)sanitize_text_field($_POST['amount']??0);
    $desc   = sanitize_text_field($_POST['description']??'Списание администратором');
    if (!$uid||$amount<=0) wp_send_json_error(['message'=>'Неверные данные']);
    $new = G24_Balance::deduct_funds($uid,$amount,$desc);
    if ($new===false) wp_send_json_error(['message'=>'Недостаточно средств']);
    wp_send_json_success(['message'=>"Списано {$amount} BYN",'new_balance'=>$new]);
} );

/* ——— Admin: approve withdrawal ——— */
add_action( 'wp_ajax_g24_admin_approve_withdrawal', function() {
    g24_check_admin();
    $id   = (int)($_POST['withdrawal_id']??0);
    $note = sanitize_text_field($_POST['note']??'');
    $result = G24_Withdrawals::approve($id,$note);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success(['message'=>'Заявка на вывод подтверждена']);
} );

/* ——— Admin: reject withdrawal ——— */
add_action( 'wp_ajax_g24_admin_reject_withdrawal', function() {
    g24_check_admin();
    $id   = (int)($_POST['withdrawal_id']??0);
    $note = sanitize_text_field($_POST['note']??'');
    $result = G24_Withdrawals::reject($id,$note);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success(['message'=>'Заявка отклонена, средства возвращены']);
} );

/* ——— Admin: approve deposit ——— */
add_action( 'wp_ajax_g24_admin_approve_deposit', function() {
    g24_check_admin();
    $id   = (int)($_POST['deposit_id']??0);
    $note = sanitize_text_field($_POST['note']??'');
    $result = G24_Deposits::approve($id,$note);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success(['message'=>'Депозит одобрен, баланс пополнен']);
} );

/* ——— Admin: reject deposit ——— */
add_action( 'wp_ajax_g24_admin_reject_deposit', function() {
    g24_check_admin();
    $id   = (int)($_POST['deposit_id']??0);
    $note = sanitize_text_field($_POST['note']??'');
    $result = G24_Deposits::reject($id,$note);
    if ( isset($result['error']) ) wp_send_json_error(['message'=>$result['error']]);
    wp_send_json_success(['message'=>'Заявка на пополнение отклонена']);
} );

/* ——— Admin: save settings ——— */
add_action( 'wp_ajax_g24_admin_save_settings', function() {
    g24_check_admin();
    $settings = [
        'win_rate'          => min(95,max(5,(int)($_POST['win_rate']??48))),
        'min_bet'           => max(0.10,(float)($_POST['min_bet']??0.10)),
        'max_bet'           => min(100000,(float)($_POST['max_bet']??1000)),
        'card_info'         => sanitize_textarea_field($_POST['card_info']??''),
        'play_page_url'     => esc_url_raw($_POST['play_page_url']??''),
        'deposit_info'      => sanitize_textarea_field($_POST['deposit_info']??''),
        'profit_protection' => isset($_POST['profit_protection']) ? (int)$_POST['profit_protection'] : 1,
    ];
    update_option('g24_casino_settings',$settings);
    wp_send_json_success(['message'=>'Настройки сохранены']);
} );
