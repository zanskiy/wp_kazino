<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$user_id  = get_current_user_id();
$balance  = G24_Balance::get_balance( $user_id );
$settings = get_option( 'g24_casino_settings', [] );
$card_info = $settings['card_info'] ?? 'Карта администратора';
$withdrawals = G24_Withdrawals::get_user_requests( $user_id, 5 );
?>
<div class="g24-casino-wrap" id="g24-roulette">

    <!-- HEADER -->
    <div class="g24-header">
        <div class="g24-logo">🎰 GOROD24 Casino</div>
        <div class="g24-header-right">
            <div class="g24-balance-box">
                <span class="g24-balance-label">Баланс:</span>
                <span class="g24-balance-value" id="g24-balance"><?php echo esc_html( number_format( $balance, 2, '.', ' ' ) ); ?></span>
                <span class="g24-currency">BYN</span>
            </div>
            <button class="g24-withdraw-trigger" id="g24-open-withdraw">💳 Вывести</button>
            <button class="g24-deposit-trigger g24-open-deposit">💰 Пополнить</button>
        </div>
    </div>

    <!-- GAME AREA -->
    <div class="g24-game-area">

        <!-- WHEEL -->
        <div class="g24-wheel-section">
            <div class="g24-wheel-wrap">
                <div class="g24-wheel-pointer">▼</div>
                <div class="g24-wheel-outer" id="g24-wheel-outer">
                    <canvas id="g24-wheel-canvas" width="320" height="320"></canvas>
                    <div class="g24-ball" id="g24-ball"></div>
                </div>
            </div>
            <div class="g24-winning-display" id="g24-winning-display">
                <div class="g24-winning-number" id="g24-winning-number">?</div>
                <div class="g24-winning-label"  id="g24-winning-label">Ждём ставки</div>
            </div>
            <div class="g24-result-message" id="g24-result-message"></div>
        </div>

        <!-- BETS -->
        <div class="g24-betting-section">

            <div class="g24-bet-amount-box">
                <label class="g24-label">Сумма ставки (BYN)</label>
                <div class="g24-bet-controls">
                    <?php foreach ( [1, 5, 10, 25, 50] as $amt ) : ?>
                        <button class="g24-bet-quick" data-amount="<?php echo $amt; ?>"><?php echo $amt; ?></button>
                    <?php endforeach; ?>
                    <button class="g24-bet-quick g24-max-btn" id="g24-bet-max">MAX</button>
                </div>
                <input type="number" id="g24-bet-amount" class="g24-input"
                       value="1"
                       min="<?php echo esc_attr( $settings['min_bet'] ?? 0.10 ); ?>"
                       max="<?php echo esc_attr( $settings['max_bet'] ?? 1000 ); ?>"
                       step="0.10"
                       placeholder="Сумма">
            </div>

            <div class="g24-bet-type-box">
                <label class="g24-label">Выберите ставку</label>
                <div class="g24-bet-tabs">
                    <button class="g24-tab active" data-tab="simple">Простые</button>
                    <button class="g24-tab" data-tab="numbers">Числа</button>
                    <button class="g24-tab" data-tab="groups">Группы</button>
                </div>

                <!-- Simple -->
                <div class="g24-tab-content active" id="g24-tab-simple">
                    <div class="g24-simple-bets">
                        <button class="g24-bet-btn g24-bet-red"   data-type="color"  data-value="red">  КРАСНОЕ <span class="g24-odds">x2</span></button>
                        <button class="g24-bet-btn g24-bet-black" data-type="color"  data-value="black">ЧЁРНОЕ  <span class="g24-odds">x2</span></button>
                        <button class="g24-bet-btn" data-type="parity" data-value="odd"> НЕЧЁТНОЕ <span class="g24-odds">x2</span></button>
                        <button class="g24-bet-btn" data-type="parity" data-value="even">ЧЁТНОЕ   <span class="g24-odds">x2</span></button>
                        <button class="g24-bet-btn" data-type="half"   data-value="low"> 1–18     <span class="g24-odds">x2</span></button>
                        <button class="g24-bet-btn" data-type="half"   data-value="high">19–36    <span class="g24-odds">x2</span></button>
                    </div>
                </div>

                <!-- Numbers -->
                <div class="g24-tab-content" id="g24-tab-numbers">
                    <div class="g24-number-grid">
                        <button class="g24-num-btn g24-num-zero" data-type="number" data-value="0">0<br><small>x36</small></button>
                        <?php
                        $red = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
                        for ( $i = 1; $i <= 36; $i++ ) :
                            $cls = in_array( $i, $red ) ? 'g24-num-red' : 'g24-num-black';
                        ?>
                        <button class="g24-num-btn <?php echo $cls; ?>" data-type="number" data-value="<?php echo $i; ?>"><?php echo $i; ?></button>
                        <?php endfor; ?>
                    </div>
                    <p class="g24-number-odds">Прямая ставка на число: выплата x36</p>
                </div>

                <!-- Groups -->
                <div class="g24-tab-content" id="g24-tab-groups">
                    <div class="g24-group-bets">
                        <div class="g24-group-row">
                            <span class="g24-group-label">Дюжины (x3):</span>
                            <button class="g24-bet-btn g24-sm" data-type="dozen" data-value="1">1–12</button>
                            <button class="g24-bet-btn g24-sm" data-type="dozen" data-value="2">13–24</button>
                            <button class="g24-bet-btn g24-sm" data-type="dozen" data-value="3">25–36</button>
                        </div>
                        <div class="g24-group-row">
                            <span class="g24-group-label">Колонки (x3):</span>
                            <button class="g24-bet-btn g24-sm" data-type="column" data-value="1">1-я</button>
                            <button class="g24-bet-btn g24-sm" data-type="column" data-value="2">2-я</button>
                            <button class="g24-bet-btn g24-sm" data-type="column" data-value="3">3-я</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="g24-selected-bet" id="g24-selected-bet"><span>Ставка не выбрана</span></div>

            <button class="g24-spin-btn" id="g24-spin-btn" disabled>
                <span class="g24-spin-text">🎲 КРУТИТЬ</span>
                <span class="g24-spin-loading" style="display:none;">⏳ Крутим...</span>
            </button>
        </div>
    </div>

    <!-- HISTORY -->
    <div class="g24-history-section">
        <h3 class="g24-history-title">История игр</h3>
        <div class="g24-history-table-wrap">
            <table class="g24-history-table">
                <thead><tr><th>Время</th><th>Ставка</th><th>Тип</th><th>Число</th><th>Результат</th><th>Выплата</th></tr></thead>
                <tbody id="g24-history-body">
                <?php
                $history = G24_Roulette::get_game_history( $user_id, 10 );
                if ( empty( $history ) ) : ?>
                    <tr><td colspan="6" class="g24-no-data">Игр пока не было</td></tr>
                <?php else : foreach ( $history as $g ) :
                    $rc = $g->result === 'win' ? 'g24-win' : 'g24-loss';
                    $rt = $g->result === 'win' ? 'Выигрыш' : 'Проигрыш';
                ?>
                    <tr class="<?php echo $rc; ?>">
                        <td><?php echo esc_html( date_i18n( 'd.m H:i', strtotime( $g->created_at ) ) ); ?></td>
                        <td><?php echo esc_html( number_format( $g->bet_amount, 2, '.', ' ' ) ); ?> BYN</td>
                        <td><?php echo esc_html( $g->bet_type . '/' . $g->bet_value ); ?></td>
                        <td><strong><?php echo esc_html( $g->winning_number ); ?></strong></td>
                        <td class="<?php echo $rc; ?>"><?php echo $rt; ?></td>
                        <td><?php echo $g->payout > 0 ? '+' . esc_html( number_format( $g->payout, 2, '.', ' ' ) ) . ' BYN' : '—'; ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- WITHDRAWAL HISTORY -->
    <?php if ( ! empty( $withdrawals ) ) : ?>
    <div class="g24-history-section">
        <h3 class="g24-history-title">Заявки на вывод</h3>
        <div class="g24-history-table-wrap">
            <table class="g24-history-table">
                <thead><tr><th>Дата</th><th>Сумма</th><th>Статус</th><th>Примечание</th></tr></thead>
                <tbody>
                <?php foreach ( $withdrawals as $w ) :
                    $s = ['pending'=>'⏳ Ожидает','approved'=>'✅ Выплачено','rejected'=>'❌ Отклонено'];
                    $sc = ['pending'=>'','approved'=>'g24-win','rejected'=>'g24-loss'];
                ?>
                <tr class="<?php echo $sc[$w->status] ?? ''; ?>">
                    <td><?php echo esc_html( date_i18n( 'd.m.Y H:i', strtotime( $w->created_at ) ) ); ?></td>
                    <td><?php echo esc_html( number_format( $w->amount, 2, '.', ' ' ) ); ?> BYN</td>
                    <td><?php echo $s[$w->status] ?? $w->status; ?></td>
                    <td><?php echo esc_html( $w->admin_note ?? '—' ); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- WITHDRAWAL MODAL -->
<div class="g24-modal-overlay" id="g24-modal-overlay" style="display:none;">
    <div class="g24-modal">
        <div class="g24-modal-header">
            <h3>💳 Заявка на вывод средств</h3>
            <button class="g24-modal-close" id="g24-modal-close">✕</button>
        </div>
        <div class="g24-modal-body">
            <div class="g24-modal-balance">
                Доступно для вывода: <strong id="g24-modal-balance-val"><?php echo esc_html( number_format( $balance, 2, '.', ' ' ) ); ?></strong> BYN
            </div>
            <div class="g24-modal-card-info">
                <strong>Реквизиты для оплаты:</strong><br>
                <?php echo esc_html( $card_info ); ?>
            </div>
            <div class="g24-form-group">
                <label>Сумма вывода (BYN)</label>
                <input type="number" id="g24-wd-amount" class="g24-input" min="1" step="0.01" placeholder="Введите сумму">
            </div>
            <div class="g24-form-group">
                <label>Ваши реквизиты карты</label>
                <textarea id="g24-wd-card" class="g24-textarea" placeholder="Номер карты, банк, имя держателя&#10;Пример: 1234 5678 9012 3456 / Беларусбанк / Иван И." rows="3"></textarea>
            </div>
            <div id="g24-wd-msg" class="g24-wd-msg"></div>
        </div>
        <div class="g24-modal-footer">
            <button class="g24-btn-cancel" id="g24-modal-close2">Отмена</button>
            <button class="g24-btn-submit" id="g24-wd-submit">Отправить заявку</button>
        </div>
    </div>
</div>

  <!-- DEPOSIT MODAL -->
  <div class="g24-modal-overlay" id="g24-dep-modal-overlay" style="display:none;">
      <div class="g24-modal">
          <div class="g24-modal-header">
              <h3>💰 Пополнение баланса</h3>
              <button class="g24-modal-close g24-dep-modal-close">✕</button>
          </div>
          <div class="g24-modal-body">
              <div class="g24-modal-card-info">
                  <strong>Реквизиты для оплаты:</strong><br>
                  <?php echo esc_html( $card_info ); ?>
              </div>
              <div class="g24-form-group">
                  <label>Сумма пополнения (BYN)</label>
                  <input type="number" id="g24-dep-amount" class="g24-input" min="1" step="0.01" placeholder="Введите сумму">
              </div>
              <div class="g24-form-group">
                  <label>Подтверждение оплаты (номер транзакции / скриншот описание)</label>
                  <textarea id="g24-dep-info" class="g24-textarea" placeholder="Например: перевод от 15.05 на сумму 50 BYN, ссылка на чек" rows="3"></textarea>
              </div>
              <div id="g24-dep-msg" style="display:none;"></div>
          </div>
          <div class="g24-modal-footer">
              <button class="g24-btn-cancel g24-dep-modal-close">Отмена</button>
              <button class="g24-btn-submit" id="g24-dep-submit">Отправить заявку</button>
          </div>
      </div>
  </div>

  <script>
  (function($){
      $(document).ready(function(){
          $(document).on('click','.g24-open-deposit',function(){
              $('#g24-dep-modal-overlay').fadeIn(200);
              $('#g24-dep-msg').hide().text('').attr('class','');
          });
          $(document).on('click','.g24-dep-modal-close',function(){
              $('#g24-dep-modal-overlay').fadeOut(200);
          });
          $('#g24-dep-modal-overlay').on('click',function(e){
              if($(e.target).is('#g24-dep-modal-overlay'))$(this).fadeOut(200);
          });
          $('#g24-dep-submit').on('click',function(){
              var amount=$('#g24-dep-amount').val();
              var info=$.trim($('#g24-dep-info').val());
              var $msg=$('#g24-dep-msg');
              if(!amount||parseFloat(amount)<1){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Минимум 1 BYN');return;}
              if(!info){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Укажите подтверждение оплаты');return;}
              var $btn=$(this).prop('disabled',true).text('Отправка...');
              $.ajax({
                  url:g24Casino.ajaxUrl,type:'POST',
                  data:{action:'g24_deposit_request',nonce:g24Casino.nonce,amount:amount,payment_info:info},
                  success:function(r){
                      if(r.success){
                          $msg.show().attr('class','g24-wd-msg g24-wd-ok').text('✅ Заявка принята! Баланс пополнится после проверки платежа.');
                          $('#g24-dep-amount,#g24-dep-info').val('');
                          setTimeout(function(){$('#g24-dep-modal-overlay').fadeOut(200);},2800);
                      } else {
                          $msg.show().attr('class','g24-wd-msg g24-wd-error').text(r.data.message||'Ошибка');
                      }
                  },
                  error:function(){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Ошибка соединения');},
                  complete:function(){$btn.prop('disabled',false).text('Отправить заявку');}
              });
          });
      });
  })(jQuery);
  </script>


  <script>
  (function($){
      $(document).ready(function(){
          $(document).on('click','.g24-open-deposit',function(){
              $('#g24-dep-modal-overlay').fadeIn(200);
              $('#g24-dep-msg').hide().text('').attr('class','');
          });
          $(document).on('click','.g24-dep-modal-close',function(){
              $('#g24-dep-modal-overlay').fadeOut(200);
          });
          $('#g24-dep-modal-overlay').on('click',function(e){
              if($(e.target).is('#g24-dep-modal-overlay'))$(this).fadeOut(200);
          });
          $('#g24-dep-submit').on('click',function(){
              var amount=$('#g24-dep-amount').val();
              var info=$.trim($('#g24-dep-info').val());
              var $msg=$('#g24-dep-msg');
              if(!amount||parseFloat(amount)<1){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Минимум 1 BYN');return;}
              if(!info){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Укажите подтверждение оплаты');return;}
              var $btn=$(this).prop('disabled',true).text('Отправка...');
              $.ajax({
                  url:g24Casino.ajaxUrl,type:'POST',
                  data:{action:'g24_deposit_request',nonce:g24Casino.nonce,amount:amount,payment_info:info},
                  success:function(r){
                      if(r.success){
                          $msg.show().attr('class','g24-wd-msg g24-wd-ok').text('✅ Заявка принята! Баланс пополнится после проверки платежа.');
                          $('#g24-dep-amount,#g24-dep-info').val('');
                          setTimeout(function(){$('#g24-dep-modal-overlay').fadeOut(200);},2800);
                      } else {
                          $msg.show().attr('class','g24-wd-msg g24-wd-error').text(r.data.message||'Ошибка');
                      }
                  },
                  error:function(){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Ошибка соединения');},
                  complete:function(){$btn.prop('disabled',false).text('Отправить заявку');}
              });
          });
      });
  })(jQuery);
  </script>
