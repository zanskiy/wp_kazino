<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_Roulette {

    private static $red_numbers = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];

    public static function get_color( $number ) {
        if ( $number === 0 ) return 'green';
        return in_array( $number, self::$red_numbers ) ? 'red' : 'black';
    }

    public static function calculate_payout( $bet_type, $bet_value, $winning_number, $bet_amount ) {
        $color = self::get_color( $winning_number );
        $won   = false;
        $mult  = 0;

        switch ( $bet_type ) {
            case 'number':
                if ( (int) $bet_value === $winning_number ) { $won = true; $mult = 35; }
                break;
            case 'color':
                if ( $winning_number !== 0 && $bet_value === $color ) { $won = true; $mult = 1; }
                break;
            case 'parity':
                if ( $winning_number !== 0 ) {
                    $odd = $winning_number % 2 !== 0;
                    if ( ($bet_value==='odd'&&$odd) || ($bet_value==='even'&&!$odd) ) { $won=true; $mult=1; }
                }
                break;
            case 'half':
                if ( $winning_number !== 0 ) {
                    $low = $winning_number <= 18;
                    if ( ($bet_value==='low'&&$low) || ($bet_value==='high'&&!$low) ) { $won=true; $mult=1; }
                }
                break;
            case 'dozen':
                $d = $winning_number>=1&&$winning_number<=12 ? 1 : ($winning_number<=24 ? 2 : ($winning_number<=36 ? 3 : 0));
                if ( $d>0 && $d===(int)$bet_value ) { $won=true; $mult=2; }
                break;
            case 'column':
                $c = $winning_number===0 ? 0 : (($winning_number-1)%3)+1;
                if ( $c>0 && $c===(int)$bet_value ) { $won=true; $mult=2; }
                break;
        }
        return [ 'won'=>$won, 'payout'=>$won ? round($bet_amount*$mult,2) : 0, 'multiplier'=>$mult ];
    }

    /**
     * Spin the wheel respecting house edge AND profit protection.
     * Returns a winning number that the casino can actually afford to pay.
     */
    private static function spin_safe( $bet_type, $bet_value, $bet_amount ) {
        $settings = get_option( 'g24_casino_settings', [] );
        $win_rate = (int) ( $settings['win_rate'] ?? 48 );

        $number = mt_rand( 0, 36 );
        $result = self::calculate_payout( $bet_type, $bet_value, $number, $bet_amount );

        if ( $result['won'] ) {
            // Step 1: house-edge chance to override the win
            if ( mt_rand(1,100) > $win_rate ) {
                $result['won'] = false;
            }

            // Step 2: even if house-edge allows the win, check casino can afford it
            if ( $result['won'] ) {
                $total_payout = $bet_amount + $result['payout']; // what player receives back
                if ( ! G24_CasinoHealth::can_payout( $total_payout ) ) {
                    $result['won'] = false;
                }
            }

            // Force a losing number if win was overridden
            if ( ! $result['won'] ) {
                $tries = 0;
                do {
                    $number = mt_rand( 0, 36 );
                    $result = self::calculate_payout( $bet_type, $bet_value, $number, $bet_amount );
                    $tries++;
                } while ( $result['won'] && $tries < 50 );
            }
        }

        return $number;
    }

    public static function place_bet( $user_id, $bet_amount, $bet_type, $bet_value ) {
        global $wpdb;
        $settings   = get_option( 'g24_casino_settings', [] );
        $min_bet    = $settings['min_bet'] ?? 0.10;
        $max_bet    = $settings['max_bet'] ?? 1000.00;
        $bet_amount = round( (float) $bet_amount, 2 );

        if ( $bet_amount < $min_bet || $bet_amount > $max_bet ) {
            return [ 'error' => "Ставка от {$min_bet} до {$max_bet} BYN" ];
        }
        if ( G24_Balance::get_balance( $user_id ) < $bet_amount ) {
            return [ 'error' => 'Недостаточно средств на балансе' ];
        }

        $winning_number = self::spin_safe( $bet_type, $bet_value, $bet_amount );
        $result         = self::calculate_payout( $bet_type, $bet_value, $winning_number, $bet_amount );

        G24_Balance::deduct_funds( $user_id, $bet_amount, "Ставка: {$bet_type}/{$bet_value}" );

        $net_payout = 0;
        if ( $result['won'] ) {
            $net_payout = $bet_amount + $result['payout']; // returns original bet + profit
            G24_Balance::credit_winnings( $user_id, $net_payout, "Выигрыш: {$bet_type}/{$bet_value}" );
        }

        // Update profit cache: house gained bet_amount, paid out net_payout
        G24_CasinoHealth::update_after_game( $bet_amount, $net_payout );

        $wpdb->insert(
            $wpdb->prefix . 'g24_games',
            [
                'user_id'        => $user_id,
                'bet_amount'     => $bet_amount,
                'bet_type'       => $bet_type,
                'bet_value'      => $bet_value,
                'winning_number' => $winning_number,
                'result'         => $result['won'] ? 'win' : 'loss',
                'payout'         => $net_payout,
                'created_at'     => current_time( 'mysql' ),
            ],
            [ '%d', '%f', '%s', '%s', '%d', '%s', '%f', '%s' ]
        );

        return [
            'success'        => true,
            'winning_number' => $winning_number,
            'color'          => self::get_color( $winning_number ),
            'won'            => $result['won'],
            'payout'         => $net_payout,
            'multiplier'     => $result['multiplier'],
            'new_balance'    => G24_Balance::get_balance( $user_id ),
        ];
    }

    public static function get_game_history( $user_id, $limit = 10 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_games WHERE user_id=%d ORDER BY created_at DESC LIMIT %d",
            $user_id, $limit
        ) );
    }

    public static function get_stats() {
        global $wpdb;
        return $wpdb->get_row(
            "SELECT COUNT(*) AS total_games, SUM(bet_amount) AS total_bets,
             SUM(payout) AS total_payouts,
             SUM(CASE WHEN result='win' THEN 1 ELSE 0 END) AS total_wins,
             SUM(bet_amount) - SUM(payout) AS house_profit
             FROM {$wpdb->prefix}g24_games"
        );
    }
}
