<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_Deposits {

    public static function create_request( $user_id, $amount, $payment_info ) {
        global $wpdb;
        $amount = round( (float) $amount, 2 );
        if ( $amount < 1 ) return [ 'error' => 'Минимальная сумма пополнения: 1 BYN' ];
        if ( empty( $payment_info ) ) return [ 'error' => 'Укажите способ/подтверждение оплаты' ];

        $wpdb->insert(
            $wpdb->prefix . 'g24_deposits',
            [
                'user_id'      => $user_id,
                'amount'       => $amount,
                'payment_info' => sanitize_text_field( $payment_info ),
                'status'       => 'pending',
                'created_at'   => current_time( 'mysql' ),
            ],
            [ '%d', '%f', '%s', '%s', '%s' ]
        );
        return [ 'success' => true ];
    }

    public static function approve( $deposit_id, $admin_note = '' ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_deposits WHERE id = %d AND status = 'pending'",
            $deposit_id
        ) );
        if ( ! $row ) return [ 'error' => 'Заявка не найдена или уже обработана' ];

        G24_Balance::add_funds( $row->user_id, $row->amount, 'Пополнение одобрено' );
        $wpdb->update(
            $wpdb->prefix . 'g24_deposits',
            [ 'status' => 'approved', 'admin_note' => $admin_note, 'processed_at' => current_time( 'mysql' ) ],
            [ 'id' => $deposit_id ],
            [ '%s', '%s', '%s' ], [ '%d' ]
        );
        return [ 'success' => true ];
    }

    public static function reject( $deposit_id, $admin_note = '' ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_deposits WHERE id = %d AND status = 'pending'",
            $deposit_id
        ) );
        if ( ! $row ) return [ 'error' => 'Заявка не найдена' ];

        $wpdb->update(
            $wpdb->prefix . 'g24_deposits',
            [ 'status' => 'rejected', 'admin_note' => $admin_note, 'processed_at' => current_time( 'mysql' ) ],
            [ 'id' => $deposit_id ],
            [ '%s', '%s', '%s' ], [ '%d' ]
        );
        return [ 'success' => true ];
    }

    public static function get_all( $status = '', $limit = 50 ) {
        global $wpdb;
        $where = $status ? $wpdb->prepare( 'WHERE d.status = %s', $status ) : '';
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT d.*, u.display_name, u.user_email,
             COALESCE((SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id=d.user_id AND meta_key='g24_phone' LIMIT 1),'—') as phone
             FROM {$wpdb->prefix}g24_deposits d
             LEFT JOIN {$wpdb->users} u ON d.user_id = u.ID
             {$where} ORDER BY d.created_at DESC LIMIT %d",
            $limit
        ) );
    }

    public static function count_pending() {
        global $wpdb;
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}g24_deposits WHERE status='pending'" );
    }

    public static function get_user_requests( $user_id, $limit = 5 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_deposits WHERE user_id=%d ORDER BY created_at DESC LIMIT %d",
            $user_id, $limit
        ) );
    }
}
