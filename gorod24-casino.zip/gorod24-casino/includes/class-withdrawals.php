<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_Withdrawals {

    public static function create_request( $user_id, $amount, $card_details ) {
        global $wpdb;
        $amount  = round( (float) $amount, 2 );
        $balance = G24_Balance::get_balance( $user_id );
        $settings = get_option( 'g24_casino_settings', [] );
        $min = 1.00;

        if ( $amount < $min ) return [ 'error' => "Минимальная сумма вывода: {$min} BYN" ];
        if ( $amount > $balance ) return [ 'error' => 'Недостаточно средств на балансе' ];

        $pending = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}g24_withdrawals WHERE user_id = %d AND status = 'pending'",
            $user_id
        ) );
        if ( $pending > 0 ) return [ 'error' => 'У вас уже есть необработанная заявка на вывод' ];

        G24_Balance::deduct_funds( $user_id, $amount, 'Заявка на вывод средств' );

        $wpdb->insert(
            $wpdb->prefix . 'g24_withdrawals',
            [
                'user_id'      => $user_id,
                'amount'       => $amount,
                'card_details' => sanitize_text_field( $card_details ),
                'status'       => 'pending',
                'created_at'   => current_time( 'mysql' ),
            ],
            [ '%d', '%f', '%s', '%s', '%s' ]
        );

        return [ 'success' => true, 'new_balance' => G24_Balance::get_balance( $user_id ) ];
    }

    public static function approve( $withdrawal_id, $admin_note = '' ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_withdrawals WHERE id = %d AND status = 'pending'",
            $withdrawal_id
        ) );
        if ( ! $row ) return [ 'error' => 'Заявка не найдена или уже обработана' ];

        $wpdb->update(
            $wpdb->prefix . 'g24_withdrawals',
            [
                'status'       => 'approved',
                'admin_note'   => $admin_note,
                'processed_at' => current_time( 'mysql' ),
            ],
            [ 'id' => $withdrawal_id ],
            [ '%s', '%s', '%s' ],
            [ '%d' ]
        );

        return [ 'success' => true ];
    }

    public static function reject( $withdrawal_id, $admin_note = '' ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_withdrawals WHERE id = %d AND status = 'pending'",
            $withdrawal_id
        ) );
        if ( ! $row ) return [ 'error' => 'Заявка не найдена или уже обработана' ];

        G24_Balance::add_funds( $row->user_id, $row->amount, 'Возврат: заявка на вывод отклонена' );

        $wpdb->update(
            $wpdb->prefix . 'g24_withdrawals',
            [
                'status'       => 'rejected',
                'admin_note'   => $admin_note,
                'processed_at' => current_time( 'mysql' ),
            ],
            [ 'id' => $withdrawal_id ],
            [ '%s', '%s', '%s' ],
            [ '%d' ]
        );

        return [ 'success' => true ];
    }

    public static function get_user_requests( $user_id, $limit = 10 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}g24_withdrawals WHERE user_id = %d ORDER BY created_at DESC LIMIT %d",
            $user_id, $limit
        ) );
    }

    public static function get_all_requests( $status = '', $limit = 50, $offset = 0 ) {
        global $wpdb;
        $where = $status ? $wpdb->prepare( "WHERE w.status = %s", $status ) : '';
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT w.*, u.display_name, u.user_email
             FROM {$wpdb->prefix}g24_withdrawals w
             LEFT JOIN {$wpdb->users} u ON w.user_id = u.ID
             {$where}
             ORDER BY w.created_at DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ) );
    }

    public static function count_pending() {
        global $wpdb;
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}g24_withdrawals WHERE status = 'pending'"
        );
    }
}
