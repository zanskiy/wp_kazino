<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_Registration {

    public static function init() {
        add_action( 'register_form',               [__CLASS__, 'add_phone_field'] );
        add_filter( 'registration_errors',         [__CLASS__, 'validate_phone'], 10, 3 );
        add_action( 'user_register',               [__CLASS__, 'save_phone'] );
        add_action( 'show_user_profile',           [__CLASS__, 'show_phone_profile'] );
        add_action( 'edit_user_profile',           [__CLASS__, 'show_phone_profile'] );
        add_action( 'personal_options_update',     [__CLASS__, 'save_phone_profile'] );
        add_action( 'edit_user_profile_update',    [__CLASS__, 'save_phone_profile'] );
        add_action( 'wp_enqueue_scripts',          [__CLASS__, 'enqueue_styles'] );
        add_filter( 'manage_users_columns',        [__CLASS__, 'add_phone_column'] );
        add_filter( 'manage_users_custom_column',  [__CLASS__, 'phone_column_value'], 10, 3 );
    }

    public static function enqueue_styles() {
        wp_enqueue_style(
            'g24-reg-style',
            G24_CASINO_URL . 'assets/css/registration.css',
            [],
            G24_CASINO_VERSION
        );
    }

    public static function add_phone_field() {
        $phone = isset( $_POST['g24_phone'] ) ? esc_attr( wp_unslash( $_POST['g24_phone'] ) ) : '';
        ?>
        <div class="g24-reg-field">
            <label for="g24_phone">
                <?php esc_html_e( 'Номер телефона', 'gorod24-casino' ); ?>
                <span class="g24-req">*</span>
            </label>
            <div class="g24-phone-wrap">
                <span class="g24-phone-prefix">+375</span>
                <input
                    type="tel"
                    name="g24_phone"
                    id="g24_phone"
                    class="input g24-phone-input"
                    value="<?php echo $phone; ?>"
                    placeholder="(XX) XXX-XX-XX"
                    maxlength="15"
                    autocomplete="tel"
                />
            </div>
            <p class="g24-phone-hint">Формат: +375 (29) 123-45-67</p>
        </div>
        <?php
    }

    public static function validate_phone( $errors, $sanitized_user_login, $user_email ) {
        $phone = isset( $_POST['g24_phone'] ) ? trim( wp_unslash( $_POST['g24_phone'] ) ) : '';

        if ( empty( $phone ) ) {
            $errors->add( 'g24_phone_error', '<strong>Ошибка:</strong> Укажите номер телефона.' );
            return $errors;
        }

        $clean = preg_replace( '/[\s\-\(\)]/', '', $phone );
        if ( ! preg_match( '/^\+?375(17|29|33|44|25)\d{7}$/', $clean ) ) {
            $errors->add( 'g24_phone_error', '<strong>Ошибка:</strong> Введите корректный белорусский номер телефона (МТС, A1, life:), Белтелеком).' );
        }

        return $errors;
    }

    public static function save_phone( $user_id ) {
        if ( isset( $_POST['g24_phone'] ) ) {
            $phone = self::normalize_phone( wp_unslash( $_POST['g24_phone'] ) );
            update_user_meta( $user_id, 'g24_phone', sanitize_text_field( $phone ) );
        }
    }

    public static function show_phone_profile( $user ) {
        $phone = get_user_meta( $user->ID, 'g24_phone', true );
        ?>
        <h3>GOROD24 Casino</h3>
        <table class="form-table">
            <tr>
                <th><label for="g24_phone_profile">Номер телефона</label></th>
                <td>
                    <input type="tel" name="g24_phone_profile" id="g24_phone_profile"
                           value="<?php echo esc_attr( $phone ); ?>"
                           class="regular-text"
                           placeholder="+375291234567" />
                    <p class="description">Ваш контактный номер телефона</p>
                </td>
            </tr>
            <tr>
                <th>Баланс казино</th>
                <td>
                    <strong><?php echo esc_html( number_format( G24_Balance::get_balance( $user->ID ), 2, '.', ' ' ) ); ?> BYN</strong>
                    <?php if ( current_user_can( 'manage_options' ) ) : ?>
                        <br><a href="<?php echo esc_url( admin_url( 'admin.php?page=g24-casino' ) ); ?>">Управление балансом →</a>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <?php
    }

    public static function save_phone_profile( $user_id ) {
        if ( ! current_user_can( 'edit_user', $user_id ) ) return;
        if ( isset( $_POST['g24_phone_profile'] ) ) {
            $phone = self::normalize_phone( wp_unslash( $_POST['g24_phone_profile'] ) );
            update_user_meta( $user_id, 'g24_phone', sanitize_text_field( $phone ) );
        }
    }

    public static function normalize_phone( $phone ) {
        $phone = preg_replace( '/[\s\-\(\)]/', '', trim( $phone ) );
        if ( preg_match( '/^375/', $phone ) ) $phone = '+' . $phone;
        if ( preg_match( '/^80/', $phone ) )  $phone = '+3' . ltrim( $phone, '8' );
        return $phone;
    }

    public static function add_phone_column( $columns ) {
        $columns['g24_phone']   = '📱 Телефон';
        $columns['g24_balance'] = '💰 Баланс';
        return $columns;
    }

    public static function phone_column_value( $value, $column_name, $user_id ) {
        if ( $column_name === 'g24_phone' ) {
            $phone = get_user_meta( $user_id, 'g24_phone', true );
            return $phone ? esc_html( $phone ) : '<span style="color:#aaa">—</span>';
        }
        if ( $column_name === 'g24_balance' ) {
            $bal = G24_Balance::get_balance( $user_id );
            return '<strong>' . esc_html( number_format( $bal, 2, '.', ' ' ) ) . '</strong> BYN';
        }
        return $value;
    }

    public static function get_phone( $user_id ) {
        return get_user_meta( $user_id, 'g24_phone', true );
    }
}
