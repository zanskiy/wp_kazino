<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_Slots {

    public static $symbols = [
        'pharaoh' => ['name'=>'Фараон',   'label'=>'👑', 'payouts'=>[3=>50, 4=>200,5=>500], 'wild'   =>true],
        'ra'      => ['name'=>'Глаз Ра',  'label'=>'☀️', 'payouts'=>[3=>20, 4=>100,5=>200], 'scatter'=>true],
        'scarab'  => ['name'=>'Скарабей', 'label'=>'🪲', 'payouts'=>[3=>15, 4=>50, 5=>100]],
        'ankh'    => ['name'=>'Анкх',     'label'=>'⚱️', 'payouts'=>[3=>10, 4=>30, 5=>75 ]],
        'cat'     => ['name'=>'Кошка',    'label'=>'🐱', 'payouts'=>[3=>5,  4=>15, 5=>40 ]],
        'gem'     => ['name'=>'Самоцвет', 'label'=>'💎', 'payouts'=>[3=>5,  4=>15, 5=>40 ]],
        'pyramid' => ['name'=>'Пирамида', 'label'=>'🔺', 'payouts'=>[3=>3,  4=>10, 5=>25 ]],
        'sand'    => ['name'=>'Песок',    'label'=>'⌛', 'payouts'=>[3=>2,  4=>8,  5=>20 ]],
    ];

    private static $symbol_keys   = ['pharaoh','ra','scarab','ankh','cat','gem','pyramid','sand'];
    private static $symbol_weights = [2, 3, 5, 6, 8, 8, 10, 10]; // total = 52

    public static $paylines = [
        'line1' => [[0,1],[1,1],[2,1],[3,1],[4,1]],
        'line2' => [[0,0],[1,0],[2,0],[3,0],[4,0]],
        'line3' => [[0,2],[1,2],[2,2],[3,2],[4,2]],
        'line4' => [[0,0],[1,1],[2,2],[3,1],[4,0]],
        'line5' => [[0,2],[1,1],[2,0],[3,1],[4,2]],
    ];

    private static function random_symbol() {
        $total = array_sum( self::$symbol_weights );
        $rand  = mt_rand( 1, $total );
        $cum   = 0;
        foreach ( self::$symbol_weights as $i => $w ) {
            $cum += $w;
            if ( $rand <= $cum ) return self::$symbol_keys[$i];
        }
        return 'sand';
    }

    private static function spin_reels() {
        $reels = [];
        for ( $r = 0; $r < 5; $r++ ) {
            $reel = [];
            for ( $row = 0; $row < 3; $row++ ) {
                $reel[] = self::random_symbol();
            }
            $reels[] = $reel;
        }
        return $reels;
    }

    private static function check_wins( $reels, $bet ) {
        $wins       = [];
        $total_mult = 0;
        $syms       = self::$symbols;

        foreach ( self::$paylines as $line_id => $positions ) {
            $line_syms = [];
            foreach ( $positions as $pos ) {
                $line_syms[] = $reels[ $pos[0] ][ $pos[1] ];
            }

            $first = null;
            foreach ( $line_syms as $s ) {
                if ( $s !== 'pharaoh' ) { $first = $s; break; }
            }
            if ( ! $first ) $first = 'pharaoh';

            $count = 0;
            foreach ( $line_syms as $s ) {
                if ( $s === $first || ( isset($syms[$s]['wild']) && $syms[$s]['wild'] ) ) $count++;
                else break;
            }

            if ( $count >= 3 ) {
                $mult = $syms[$first]['payouts'][$count] ?? $syms[$first]['payouts'][3];
                $wins[]      = ['line'=>$line_id,'symbol'=>$first,'count'=>$count,'mult'=>$mult,'payout'=>round($bet*$mult,2)];
                $total_mult += $mult;
            }
        }

        // Scatter
        $scatter_count = 0;
        foreach ( $reels as $reel ) {
            foreach ( $reel as $s ) { if ($s==='ra') $scatter_count++; }
        }
        $free_spins = 0;
        if ( $scatter_count >= 3 ) {
            $scatter_mult = $syms['ra']['payouts'][min($scatter_count,5)];
            $wins[]      = ['line'=>'scatter','symbol'=>'ra','count'=>$scatter_count,'mult'=>$scatter_mult,'payout'=>round($bet*$scatter_mult,2)];
            $total_mult += $scatter_mult;
            $free_spins  = 10;
        }

        return ['wins'=>$wins,'total_mult'=>$total_mult,'free_spins'=>$free_spins];
    }

    public static function spin( $user_id, $bet_amount ) {
        $settings   = get_option( 'g24_casino_settings', [] );
        $min_bet    = $settings['min_bet'] ?? 0.10;
        $max_bet    = $settings['max_bet'] ?? 1000.00;
        $win_rate   = (int) ( $settings['win_rate'] ?? 48 );
        $bet_amount = round( (float) $bet_amount, 2 );

        if ( $bet_amount < $min_bet || $bet_amount > $max_bet ) {
            return ['error' => "Ставка от {$min_bet} до {$max_bet} BYN"];
        }
        if ( G24_Balance::get_balance($user_id) < $bet_amount ) {
            return ['error' => 'Недостаточно средств'];
        }

        // Spin
        $reels  = self::spin_reels();
        $result = self::check_wins( $reels, $bet_amount );

        // 1) House-edge override
        if ( $result['total_mult'] > 0 && mt_rand(1,100) > $win_rate ) {
            $tries = 0;
            do {
                $reels  = self::spin_reels();
                $result = self::check_wins( $reels, $bet_amount );
                $tries++;
            } while ( $result['total_mult'] > 0 && $tries < 10 );
        }

        // 2) Profit-protection override — casino cannot go negative
        $total_payout = round( $bet_amount * $result['total_mult'], 2 );
        if ( $total_payout > 0 && ! G24_CasinoHealth::can_payout( $total_payout ) ) {
            // Force a losing spin
            $tries = 0;
            do {
                $reels  = self::spin_reels();
                $result = self::check_wins( $reels, $bet_amount );
                $tries++;
            } while ( $result['total_mult'] > 0 && $tries < 20 );
            $total_payout = 0;
            $result['wins']       = [];
            $result['total_mult'] = 0;
            $result['free_spins'] = 0;
        }

        // Apply bet & credit
        G24_Balance::deduct_funds( $user_id, $bet_amount, 'Ставка: Египетские слоты' );
        if ( $total_payout > 0 ) {
            G24_Balance::credit_winnings( $user_id, $total_payout, 'Выигрыш: Слоты x' . $result['total_mult'] );
        }

        G24_CasinoHealth::update_after_game( $bet_amount, $total_payout );

        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'g24_games', [
            'user_id'        => $user_id,
            'bet_amount'     => $bet_amount,
            'bet_type'       => 'slots',
            'bet_value'      => 'egypt',
            'winning_number' => $result['total_mult'],
            'result'         => $total_payout > 0 ? 'win' : 'loss',
            'payout'         => $total_payout,
            'created_at'     => current_time('mysql'),
        ], ['%d','%f','%s','%s','%d','%s','%f','%s'] );

        return [
            'success'     => true,
            'reels'       => $reels,
            'wins'        => $result['wins'],
            'total_mult'  => $result['total_mult'],
            'payout'      => $total_payout,
            'free_spins'  => $result['free_spins'],
            'new_balance' => G24_Balance::get_balance( $user_id ),
        ];
    }
}
