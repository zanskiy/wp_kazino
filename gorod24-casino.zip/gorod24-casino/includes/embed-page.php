<?php
  if ( ! defined( 'ABSPATH' ) ) exit;
  /**
   * Standalone embed page — rendered when ?g24_embed=1 is present.
   * Serves just the casino UI without any WordPress theme wrapper.
   */

  $user_id  = get_current_user_id();
  $balance  = $user_id ? G24_Balance::get_balance( $user_id ) : 0;
  $settings = get_option( 'g24_casino_settings', [] );
  $card_info = $settings['card_info'] ?? '';

  // Enqueue scripts and styles manually
  wp_enqueue_script( 'jquery' );
  wp_enqueue_style(  'g24-roulette',   G24_CASINO_PLUGIN_URL . 'assets/css/roulette.css',  [], G24_CASINO_VERSION );
  wp_enqueue_style(  'g24-slots',      G24_CASINO_PLUGIN_URL . 'assets/css/slots.css',     [], G24_CASINO_VERSION );
  wp_enqueue_style(  'g24-seabattle',  G24_CASINO_PLUGIN_URL . 'assets/css/seabattle.css', [], G24_CASINO_VERSION );
  wp_enqueue_script( 'g24-roulette',   G24_CASINO_PLUGIN_URL . 'assets/js/roulette.js',    ['jquery'], G24_CASINO_VERSION, true );
  wp_enqueue_script( 'g24-slots',      G24_CASINO_PLUGIN_URL . 'assets/js/slots.js',       ['jquery'], G24_CASINO_VERSION, true );
  wp_enqueue_script( 'g24-seabattle',  G24_CASINO_PLUGIN_URL . 'assets/js/seabattle.js',   ['jquery'], G24_CASINO_VERSION, true );

  wp_localize_script( 'g24-roulette', 'g24Casino', [
      'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
      'nonce'     => wp_create_nonce( 'g24_casino_nonce' ),
      'userId'    => $user_id,
      'balance'   => $balance,
      'maxBet'    => $settings['max_bet'] ?? 1000,
      'currency'  => 'BYN',
  ] );
  ?>
  <!DOCTYPE html>
  <html lang="ru">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>GOROD24 Casino</title>
  <?php wp_head(); ?>
  <style>
  *{box-sizing:border-box;margin:0;padding:0;}
  html,body{background:#0d1117;min-height:100%;font-family:'Segoe UI',sans-serif;color:#e6edf3;}
  body{padding:0;}
  .g24-embed-wrap{max-width:100%;overflow-x:hidden;}
  /* Game navigation */
  .g24-embed-nav{display:flex;gap:4px;padding:10px 14px;background:#0d1117;border-bottom:2px solid #d4af37;flex-wrap:wrap;}
  .g24-embed-tab{background:#161b22;border:1px solid #30363d;color:#7d8590;padding:9px 20px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:700;transition:all .2s;letter-spacing:.3px;}
  .g24-embed-tab:hover{border-color:#d4af37;color:#d4af37;}
  .g24-embed-tab.active{background:linear-gradient(135deg,#d4af37,#b8962e);color:#000;border-color:#d4af37;}
  .g24-embed-panel{display:none;}
  .g24-embed-panel.active{display:block;}
  /* Login notice */
  .g24-embed-login{text-align:center;padding:60px 20px;color:#7d8590;}
  .g24-embed-login a{color:#d4af37;font-weight:700;}
  .g24-embed-login-btn{display:inline-block;margin-top:16px;background:linear-gradient(135deg,#d4af37,#b8962e);color:#000;padding:12px 28px;border-radius:8px;font-weight:700;font-size:16px;text-decoration:none;transition:transform .2s;}
  .g24-embed-login-btn:hover{transform:translateY(-2px);}
  </style>
  </head>
  <body>
  <div class="g24-embed-wrap">

  <?php if ( ! is_user_logged_in() ) : ?>
      <div class="g24-embed-login">
          <p style="font-size:22px;margin-bottom:8px;">🎰 GOROD24 Casino</p>
          <p style="margin-bottom:16px;">Войдите, чтобы играть и получать выигрыши</p>
          <a class="g24-embed-login-btn" href="<?php echo esc_url( wp_login_url( home_url( '/?g24_embed=1' ) ) ); ?>">Войти / Зарегистрироваться</a>
      </div>
  <?php else : ?>

      <div class="g24-embed-nav">
          <button class="g24-embed-tab active" onclick="g24EmbedSwitch(this,'roulette')">🎰 Рулетка</button>
          <button class="g24-embed-tab" onclick="g24EmbedSwitch(this,'slots')">🎲 Слоты</button>
          <button class="g24-embed-tab" onclick="g24EmbedSwitch(this,'seabattle')">⚓ Морской Бой</button>
      </div>

      <div id="g24ep-roulette" class="g24-embed-panel active">
          <?php echo do_shortcode('[gorod24_roulette]'); ?>
      </div>
      <div id="g24ep-slots" class="g24-embed-panel">
          <?php echo do_shortcode('[gorod24_slots]'); ?>
      </div>
      <div id="g24ep-seabattle" class="g24-embed-panel">
          <?php echo do_shortcode('[gorod24_seabattle]'); ?>
      </div>

  <?php endif; ?>
  </div>

  <script>
  function g24EmbedSwitch(btn, panel) {
      document.querySelectorAll('.g24-embed-tab').forEach(function(t){ t.classList.remove('active'); });
      document.querySelectorAll('.g24-embed-panel').forEach(function(p){ p.classList.remove('active'); });
      btn.classList.add('active');
      document.getElementById('g24ep-' + panel).classList.add('active');
  }
  </script>
  <?php wp_footer(); ?>
  </body>
  </html>
  <?php
  exit;
  