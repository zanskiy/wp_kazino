<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$user_id  = get_current_user_id();
$balance  = G24_Balance::get_balance( $user_id );
$settings = get_option( 'g24_casino_settings', [] );
$symbols  = G24_Slots::$symbols;
$card_info = $settings['card_info'] ?? 'Карта администратора';
?>
<div class="g24-slots-wrap" id="g24-slots">

    <!-- HEADER -->
    <div class="g24-slots-header">
        <div class="g24-slots-title">🏺 Египетские Слоты</div>
        <div class="g24-slots-balance-box">
            <span class="g24-slots-bal-label">Баланс:</span>
            <span class="g24-slots-bal-val" id="g24-slots-balance"><?php echo esc_html( number_format( $balance, 2, '.', ' ' ) ); ?></span>
            <span>BYN</span>
        </div>
    </div>

    <!-- DECORATIVE HIEROGLYPHS -->
    <div class="g24-slots-hiero">𓂀 𓃀 𓆣 𓅓 𓆙 𓆑 𓃭 𓅱</div>

    <!-- MACHINE -->
    <div class="g24-slots-machine">
        <div class="g24-slots-top-deco">
            <div class="g24-slots-eye">👁️</div>
            <div class="g24-slots-machine-title">EGYPT FORTUNE</div>
            <div class="g24-slots-eye">👁️</div>
        </div>

        <!-- REELS -->
        <div class="g24-slots-reels-wrap">
            <div class="g24-slots-reels" id="g24-reels">
                <?php for ( $i = 0; $i < 5; $i++ ) : ?>
                <div class="g24-reel" id="g24-reel-<?php echo $i; ?>">
                    <div class="g24-reel-inner" id="g24-reel-inner-<?php echo $i; ?>">
                        <!-- symbols filled by JS -->
                    </div>
                    <div class="g24-reel-highlight"></div>
                </div>
                <?php endfor; ?>
            </div>
            <div class="g24-slots-payline-line"></div>
        </div>

        <!-- WIN DISPLAY -->
        <div class="g24-slots-win-display" id="g24-slots-win-display" style="display:none;">
            <span class="g24-slots-win-label" id="g24-slots-win-label"></span>
        </div>

        <!-- BET CONTROLS -->
        <div class="g24-slots-controls">
            <div class="g24-slots-bet-row">
                <label class="g24-slots-label">Ставка (BYN)</label>
                <div class="g24-slots-bet-btns">
                    <?php foreach ( [0.5, 1, 5, 10, 25] as $b ) : ?>
                        <button class="g24-slots-quick" data-amount="<?php echo $b; ?>"><?php echo $b; ?></button>
                    <?php endforeach; ?>
                </div>
                <input type="number" id="g24-slots-bet" class="g24-slots-input" value="1"
                       min="<?php echo esc_attr( $settings['min_bet'] ?? 0.10 ); ?>"
                       max="<?php echo esc_attr( $settings['max_bet'] ?? 1000 ); ?>"
                       step="0.50">
            </div>
            <div class="g24-slots-lines-info">5 линий выплат &bull; Wild: 👑 Фараон &bull; Scatter: ☀️ Глаз Ра</div>
            <button class="g24-slots-spin-btn" id="g24-slots-spin">
                <span class="g24-slots-spin-text">⚡ КРУТИТЬ</span>
                <span class="g24-slots-spin-load" style="display:none;">⏳ Крутим...</span>
            </button>
        </div>
    </div>

    <!-- FREE SPINS INDICATOR -->
    <div class="g24-free-spins-banner" id="g24-free-spins-banner" style="display:none;">
        🎉 <span id="g24-free-spins-count">0</span> БЕСПЛАТНЫХ СПИНОВ!
    </div>

    <!-- PAYLINES TABLE -->
    <div class="g24-slots-paylines">
        <div class="g24-slots-section-title">📜 Линии выплат</div>
        <div class="g24-paylines-grid">
            <?php foreach ( G24_Slots::$paylines as $lid => $positions ) :
                $names = ['line1'=>'Середина','line2'=>'Верх','line3'=>'Низ','line4'=>'V-образная','line5'=>'^-образная'];
            ?>
            <div class="g24-payline-item">
                <div class="g24-payline-mini">
                    <?php
                    $grid = array_fill(0, 3, array_fill(0, 5, false));
                    foreach ($positions as $p) { $grid[$p[1]][$p[0]] = true; }
                    for ($row=0;$row<3;$row++) { echo '<div class="g24-pl-row">';
                        for ($col=0;$col<5;$col++) { echo '<div class="g24-pl-cell '.($grid[$row][$col]?'active':'').'"></div>'; }
                    echo '</div>'; }
                    ?>
                </div>
                <span class="g24-payline-name"><?php echo $names[$lid] ?? $lid; ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- PAYTABLE -->
    <div class="g24-slots-paytable">
        <div class="g24-slots-section-title">💰 Таблица выплат (множитель ставки)</div>
        <div class="g24-slots-rules-toggle" id="g24-slots-rules-toggle">📖 Правила игры ▼</div>
        <div class="g24-slots-rules-text" id="g24-slots-rules-text" style="display:none;">
            <ul>
                <li><strong>5 барабанов × 3 ряда</strong> — 5 активных линий выплат</li>
                <li><strong>👑 Фараон (Wild)</strong> — заменяет любой символ кроме Scatter</li>
                <li><strong>☀️ Глаз Ра (Scatter)</strong> — 3+ в любом месте = 10 бесплатных спинов</li>
                <li>Выигрыш считается <strong>слева направо</strong> на активных линиях</li>
                <li>Минимум <strong>3 одинаковых символа</strong> подряд для выплаты</li>
                <li>Бесплатные спины начисляются автоматически и прокручиваются подряд</li>
            </ul>
        </div>
        <table class="g24-paytable-table">
            <thead><tr><th>Символ</th><th>3 в ряд</th><th>4 в ряд</th><th>5 в ряд</th></tr></thead>
            <tbody>
                <?php foreach ( $symbols as $key => $sym ) : ?>
                <tr class="<?php echo isset($sym['wild'])?'g24-wild-row':(isset($sym['scatter'])?'g24-scatter-row':''); ?>">
                    <td>
                        <span class="g24-sym-emoji"><?php echo $sym['label']; ?></span>
                        <span class="g24-sym-name"><?php echo esc_html($sym['name']); ?></span>
                        <?php if (isset($sym['wild'])) echo '<span class="g24-sym-badge">WILD</span>'; ?>
                        <?php if (isset($sym['scatter'])) echo '<span class="g24-sym-badge g24-badge-scatter">SCATTER</span>'; ?>
                    </td>
                    <td>x<?php echo $sym['payouts'][3]; ?></td>
                    <td>x<?php echo $sym['payouts'][4]; ?></td>
                    <td>x<?php echo $sym['payouts'][5]; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

  <!-- DEPOSIT MODAL -->
  <div class="g24-modal-overlay" id="g24-dep-modal-overlay" style="display:none;">
      <div class="g24-modal">
          <div class="g24-modal-header">
              <h3>💰 Пополнение баланса</h3>
              <button class="g24-modal-close g24-dep-modal-close">✕</button>
          </div>
          <div class="g24-modal-body">
              <div class="g24-modal-card-info">
                  <strong>Реквизиты для оплаты:</strong><br>
                  <?php echo esc_html( $card_info ); ?>
              </div>
              <div class="g24-form-group">
                  <label>Сумма пополнения (BYN)</label>
                  <input type="number" id="g24-dep-amount" class="g24-input" min="1" step="0.01" placeholder="Введите сумму">
              </div>
              <div class="g24-form-group">
                  <label>Подтверждение оплаты (номер транзакции / скриншот описание)</label>
                  <textarea id="g24-dep-info" class="g24-textarea" placeholder="Например: перевод от 15.05 на сумму 50 BYN, ссылка на чек" rows="3"></textarea>
              </div>
              <div id="g24-dep-msg" style="display:none;"></div>
          </div>
          <div class="g24-modal-footer">
              <button class="g24-btn-cancel g24-dep-modal-close">Отмена</button>
              <button class="g24-btn-submit" id="g24-dep-submit">Отправить заявку</button>
          </div>
      </div>
  </div>

  <script>
  (function($){
      $(document).ready(function(){
          $(document).on('click','.g24-open-deposit',function(){
              $('#g24-dep-modal-overlay').fadeIn(200);
              $('#g24-dep-msg').hide().text('').attr('class','');
          });
          $(document).on('click','.g24-dep-modal-close',function(){
              $('#g24-dep-modal-overlay').fadeOut(200);
          });
          $('#g24-dep-modal-overlay').on('click',function(e){
              if($(e.target).is('#g24-dep-modal-overlay'))$(this).fadeOut(200);
          });
          $('#g24-dep-submit').on('click',function(){
              var amount=$('#g24-dep-amount').val();
              var info=$.trim($('#g24-dep-info').val());
              var $msg=$('#g24-dep-msg');
              if(!amount||parseFloat(amount)<1){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Минимум 1 BYN');return;}
              if(!info){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Укажите подтверждение оплаты');return;}
              var $btn=$(this).prop('disabled',true).text('Отправка...');
              $.ajax({
                  url:g24Casino.ajaxUrl,type:'POST',
                  data:{action:'g24_deposit_request',nonce:g24Casino.nonce,amount:amount,payment_info:info},
                  success:function(r){
                      if(r.success){
                          $msg.show().attr('class','g24-wd-msg g24-wd-ok').text('✅ Заявка принята! Баланс пополнится после проверки платежа.');
                          $('#g24-dep-amount,#g24-dep-info').val('');
                          setTimeout(function(){$('#g24-dep-modal-overlay').fadeOut(200);},2800);
                      } else {
                          $msg.show().attr('class','g24-wd-msg g24-wd-error').text(r.data.message||'Ошибка');
                      }
                  },
                  error:function(){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Ошибка соединения');},
                  complete:function(){$btn.prop('disabled',false).text('Отправить заявку');}
              });
          });
      });
  })(jQuery);
  </script>
