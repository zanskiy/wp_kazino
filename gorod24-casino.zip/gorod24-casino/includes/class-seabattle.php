<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class G24_SeaBattle {

    const SIZE  = 10;
    const SHIPS = [[4,1],[3,2],[2,3],[1,4]]; // [size, count]

    public static function start_game( $user_id, $bet_amount ) {
        $settings   = get_option( 'g24_casino_settings', [] );
        $min_bet    = $settings['min_bet'] ?? 0.10;
        $max_bet    = $settings['max_bet'] ?? 1000.00;
        $bet_amount = round( (float) $bet_amount, 2 );

        if ( $bet_amount < $min_bet || $bet_amount > $max_bet ) {
            return ['error' => "Ставка от {$min_bet} до {$max_bet} BYN"];
        }
        if ( G24_Balance::get_balance($user_id) < $bet_amount ) {
            return ['error' => 'Недостаточно средств'];
        }

        G24_Balance::deduct_funds( $user_id, $bet_amount, 'Ставка: Морской бой' );

        $player_board   = self::empty_board();
        $opponent_board = self::empty_board();
        self::place_ships_random( $player_board );
        self::place_ships_random( $opponent_board );

        $game = [
            'player_board'    => $player_board,
            'opponent_board'  => $opponent_board,
            'opponent_reveal' => self::empty_board(),
            'player_shots'    => [],
            'opponent_shots'  => [],
            'status'          => 'playing',
            'bet'             => $bet_amount,
            'player_hits'     => 0,
            'opponent_hits'   => 0,
            'ships_total'     => self::count_ships_cells(),
        ];

        update_user_meta( $user_id, 'g24_seabattle_game', wp_json_encode($game) );

        return [
            'success'      => true,
            'player_board' => $player_board,
            'player_shots' => [],
            'bet'          => $bet_amount,
            'ships_total'  => $game['ships_total'],
        ];
    }

    public static function shoot( $user_id, $row, $col ) {
        $raw = get_user_meta( $user_id, 'g24_seabattle_game', true );
        if ( ! $raw ) return ['error' => 'Игра не найдена. Начните новую.'];

        $game = json_decode( $raw, true );
        if ( $game['status'] !== 'playing' ) return ['error' => 'Игра завершена.'];

        $key = $row . '_' . $col;
        if ( in_array($key, $game['player_shots']) ) return ['error' => 'Вы уже стреляли сюда.'];

        $game['player_shots'][] = $key;
        $cell                   = $game['opponent_board'][$row][$col];
        $player_hit             = false;

        if ( $cell === 1 ) {
            $game['opponent_board'][$row][$col]  = 2;
            $game['opponent_reveal'][$row][$col] = 2;
            $game['player_hits']++;
            $player_hit = true;
        } else {
            $game['opponent_reveal'][$row][$col] = 3;
        }

        $game_over  = false;
        $player_won = false;
        if ( $game['player_hits'] >= $game['ships_total'] ) {
            $game['status'] = 'won';
            $game_over  = true;
            $player_won = true;
        }

        // Opponent's return shot
        $opp_row = null; $opp_col = null; $opp_hit = false;
        if ( ! $game_over ) {
            $shot = self::opponent_shoot( $game );
            if ( $shot ) {
                $opp_row = $shot['row'];
                $opp_col = $shot['col'];
                $opp_hit = $shot['hit'];
                if ($opp_hit) {
                    $game['player_board'][$opp_row][$opp_col] = 2;
                    $game['opponent_hits']++;
                } else {
                    $game['player_board'][$opp_row][$opp_col] = 3;
                }
                $game['opponent_shots'][] = $opp_row . '_' . $opp_col;

                if ( $game['opponent_hits'] >= $game['ships_total'] ) {
                    $game['status'] = 'lost';
                    $game_over  = true;
                    $player_won = false;
                }
            }
        }

        $payout      = 0;
        $new_balance = G24_Balance::get_balance($user_id);

        if ( $game_over ) {
            if ( $player_won ) {
                $proposed_payout = $game['bet'] * 2; // win = 2× bet
                // Profit protection: if casino can't afford, no payout
                if ( G24_CasinoHealth::can_payout($proposed_payout) ) {
                    $payout = $proposed_payout;
                    G24_Balance::credit_winnings( $user_id, $payout, 'Выигрыш: Морской бой' );
                } else {
                    // Can still give back the original bet as consolation
                    $payout = $game['bet'];
                    G24_Balance::credit_winnings( $user_id, $payout, 'Возврат ставки: Морской бой' );
                }
                $new_balance = G24_Balance::get_balance($user_id);
            }

            G24_CasinoHealth::update_after_game( $game['bet'], $payout );
            delete_user_meta( $user_id, 'g24_seabattle_game' );

            global $wpdb;
            $wpdb->insert( $wpdb->prefix . 'g24_games', [
                'user_id'        => $user_id,
                'bet_amount'     => $game['bet'],
                'bet_type'       => 'seabattle',
                'bet_value'      => 'classic',
                'winning_number' => $game['player_hits'],
                'result'         => $player_won ? 'win' : 'loss',
                'payout'         => $payout,
                'created_at'     => current_time('mysql'),
            ], ['%d','%f','%s','%s','%d','%s','%f','%s'] );
        } else {
            update_user_meta( $user_id, 'g24_seabattle_game', wp_json_encode($game) );
        }

        return [
            'success'         => true,
            'player_hit'      => $player_hit,
            'player_row'      => (int) $row,
            'player_col'      => (int) $col,
            'opp_row'         => $opp_row,
            'opp_col'         => $opp_col,
            'opp_hit'         => $opp_hit,
            'player_hits'     => $game['player_hits'],
            'opponent_hits'   => $game['opponent_hits'],
            'ships_total'     => $game['ships_total'],
            'game_over'       => $game_over,
            'player_won'      => $player_won,
            'payout'          => $payout,
            'new_balance'     => $new_balance,
            'opponent_reveal' => $game['opponent_reveal'],
            'player_board'    => $game['player_board'],
        ];
    }

    public static function surrender( $user_id ) {
        $raw = get_user_meta( $user_id, 'g24_seabattle_game', true );
        if ( ! $raw ) return ['error' => 'Нет активной игры'];
        $game = json_decode( $raw, true );
        delete_user_meta( $user_id, 'g24_seabattle_game' );
        G24_CasinoHealth::update_after_game( $game['bet'], 0 );
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'g24_games', [
            'user_id'        => $user_id,
            'bet_amount'     => $game['bet'],
            'bet_type'       => 'seabattle',
            'bet_value'      => 'surrendered',
            'winning_number' => 0,
            'result'         => 'loss',
            'payout'         => 0,
            'created_at'     => current_time('mysql'),
        ], ['%d','%f','%s','%s','%d','%s','%f','%s'] );
        return ['success' => true, 'opponent_board' => $game['opponent_board']];
    }

    public static function get_active_game( $user_id ) {
        $raw = get_user_meta( $user_id, 'g24_seabattle_game', true );
        if ( ! $raw ) return null;
        $g = json_decode( $raw, true );
        return [
            'player_board'    => $g['player_board'],
            'opponent_reveal' => $g['opponent_reveal'],
            'player_shots'    => $g['player_shots'],
            'opponent_shots'  => $g['opponent_shots'],
            'player_hits'     => $g['player_hits'],
            'opponent_hits'   => $g['opponent_hits'],
            'ships_total'     => $g['ships_total'],
            'bet'             => $g['bet'],
        ];
    }

    private static function empty_board() {
        $b = [];
        for ($r=0;$r<self::SIZE;$r++) { $b[$r] = array_fill(0,self::SIZE,0); }
        return $b;
    }

    private static function count_ships_cells() {
        $t = 0;
        foreach (self::SHIPS as $s) { $t += $s[0]*$s[1]; }
        return $t;
    }

    private static function place_ships_random( &$board ) {
        foreach (self::SHIPS as [$size,$count]) {
            for ($n=0;$n<$count;$n++) {
                $placed=false; $tries=0;
                while (!$placed&&$tries<200) {
                    $tries++;
                    $horiz=mt_rand(0,1);
                    $row=mt_rand(0,self::SIZE-($horiz?1:$size));
                    $col=mt_rand(0,self::SIZE-($horiz?$size:1));
                    if (self::can_place($board,$row,$col,$size,$horiz)) {
                        for ($i=0;$i<$size;$i++) {
                            if ($horiz) $board[$row][$col+$i]=1;
                            else        $board[$row+$i][$col]=1;
                        }
                        $placed=true;
                    }
                }
            }
        }
    }

    private static function can_place($board,$row,$col,$size,$horiz) {
        for ($i=0;$i<$size;$i++) {
            $r=$horiz?$row:$row+$i; $c=$horiz?$col+$i:$col;
            for ($dr=-1;$dr<=1;$dr++) { for ($dc=-1;$dc<=1;$dc++) {
                $nr=$r+$dr; $nc=$c+$dc;
                if ($nr>=0&&$nr<self::SIZE&&$nc>=0&&$nc<self::SIZE&&$board[$nr][$nc]===1) return false;
            }}
        }
        return true;
    }

    private static function opponent_shoot(&$game) {
        $avail=[];
        for ($r=0;$r<self::SIZE;$r++) { for ($c=0;$c<self::SIZE;$c++) {
            if (!in_array($r.'_'.$c,$game['opponent_shots'])) $avail[]=[$r,$c];
        }}
        if (empty($avail)) return null;
        $pick=$avail[array_rand($avail)];
        $cell=$game['player_board'][$pick[0]][$pick[1]];
        return ['row'=>$pick[0],'col'=>$pick[1],'hit'=>($cell===1||$cell===2)];
    }
}
