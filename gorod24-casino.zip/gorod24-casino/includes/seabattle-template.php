<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$user_id    = get_current_user_id();
$balance    = G24_Balance::get_balance( $user_id );
$settings   = get_option( 'g24_casino_settings', [] );
$active     = G24_SeaBattle::get_active_game( $user_id );
$settings   = get_option( 'g24_casino_settings', [] );
$card_info  = $settings['card_info'] ?? 'Карта администратора';
?>
<div class="g24-sb-wrap" id="g24-seabattle">

    <div class="g24-sb-header">
        <div class="g24-sb-title">⚓ Морской Бой</div>
        <div class="g24-sb-balance-box">
            <span>Баланс:</span>
            <span class="g24-sb-bal" id="g24-sb-balance"><?php echo esc_html( number_format( $balance, 2, '.', ' ' ) ); ?></span>
            <span>BYN</span>
        </div>
    </div>

    <!-- START SCREEN -->
    <div class="g24-sb-start" id="g24-sb-start" <?php if ($active) echo 'style="display:none;"'; ?>>
        <div class="g24-sb-start-inner">
            <div class="g24-sb-fleet">🚢 🛳️ ⛵ 🚤</div>
            <h2>Добро пожаловать в Морской Бой!</h2>
            <div class="g24-sb-rules-box">
                <h3>📋 Правила</h3>
                <ul>
                    <li>Поле 10×10, вы против компьютера</li>
                    <li>Ваши корабли расставляются автоматически</li>
                    <li>Стреляйте по полю противника — нажимайте на клетки</li>
                    <li>Ходите по очереди. Попадание — стреляете ещё раз!</li>
                    <li>Кто первый потопит все корабли — <strong>побеждает</strong></li>
                    <li><strong>Победа = ставка × 2</strong> (выплата включает возврат ставки)</li>
                </ul>
                <div class="g24-sb-ships-legend">
                    <div><span class="g24-sb-ship-demo" style="width:40px;"></span> Линкор (4 клетки) × 1</div>
                    <div><span class="g24-sb-ship-demo" style="width:30px;"></span> Крейсер (3 клетки) × 2</div>
                    <div><span class="g24-sb-ship-demo" style="width:20px;"></span> Эсминец (2 клетки) × 3</div>
                    <div><span class="g24-sb-ship-demo" style="width:10px;"></span> Катер (1 клетка) × 4</div>
                </div>
            </div>
            <div class="g24-sb-bet-row">
                <label>Ставка (BYN):</label>
                <div class="g24-sb-bet-btns">
                    <?php foreach ([1,5,10,25,50] as $b): ?>
                    <button class="g24-sb-quick" data-amount="<?php echo $b; ?>"><?php echo $b; ?></button>
                    <?php endforeach; ?>
                </div>
                <input type="number" id="g24-sb-bet-input" class="g24-sb-input"
                       value="1"
                       min="<?php echo esc_attr($settings['min_bet'] ?? 0.10); ?>"
                       max="<?php echo esc_attr($settings['max_bet'] ?? 1000); ?>"
                       step="0.50">
            </div>
            <div class="g24-sb-win-info">При победе вы получите: <strong id="g24-sb-win-preview">2.00 BYN</strong></div>
            <button class="g24-sb-start-btn" id="g24-sb-start-btn">⚓ НАЧАТЬ ИГРУ</button>
            <div id="g24-sb-start-msg" class="g24-sb-msg" style="display:none;"></div>
        </div>
    </div>

    <!-- GAME SCREEN -->
    <div class="g24-sb-game" id="g24-sb-game" <?php if (!$active) echo 'style="display:none;"'; ?>>

        <div class="g24-sb-status-bar">
            <div class="g24-sb-status-item">
                ⚔️ Ваши попадания: <strong id="g24-sb-my-hits">0</strong> / <span id="g24-sb-total"><?php echo $active ? $active['ships_total'] : 20; ?></span>
            </div>
            <div class="g24-sb-status-item g24-sb-bet-info">
                Ставка: <strong id="g24-sb-current-bet"><?php echo $active ? number_format($active['bet'],2,'.',' ') : '0.00'; ?></strong> BYN
            </div>
            <div class="g24-sb-status-item">
                💣 Попадания врага: <strong id="g24-sb-opp-hits">0</strong>
            </div>
        </div>

        <div class="g24-sb-turn-indicator" id="g24-sb-turn">🎯 Ваш ход — выберите клетку на поле противника</div>

        <div class="g24-sb-boards">
            <div class="g24-sb-board-section">
                <div class="g24-sb-board-label">🚢 Ваши корабли</div>
                <div class="g24-sb-grid" id="g24-sb-player-grid">
                    <?php for($r=0;$r<10;$r++): for($c=0;$c<10;$c++):
                        $cell = $active ? $active['player_board'][$r][$c] : 0;
                        $cls = $cell===1?'g24-sb-ship':($cell===2?'g24-sb-hit':($cell===3?'g24-sb-miss':''));
                    ?>
                    <div class="g24-sb-cell <?php echo $cls; ?>" data-r="<?php echo $r; ?>" data-c="<?php echo $c; ?>"></div>
                    <?php endfor; endfor; ?>
                </div>
                <div class="g24-sb-legend"><span class="g24-leg-ship"></span>Корабль <span class="g24-leg-hit"></span>Попадание <span class="g24-leg-miss"></span>Промах</div>
            </div>

            <div class="g24-sb-board-section">
                <div class="g24-sb-board-label">🌊 Поле противника</div>
                <div class="g24-sb-grid g24-sb-enemy-grid" id="g24-sb-enemy-grid">
                    <?php for($r=0;$r<10;$r++): for($c=0;$c<10;$c++):
                        $reveal = $active ? ($active['opponent_reveal'][$r][$c] ?? 0) : 0;
                        $shot   = $active ? in_array($r.'_'.$c, $active['player_shots']) : false;
                        $cls = $reveal===2?'g24-sb-hit':($reveal===3?'g24-sb-miss':'');
                        $disabled = $shot ? 'g24-sb-disabled' : '';
                    ?>
                    <div class="g24-sb-cell g24-sb-clickable <?php echo $cls.' '.$disabled; ?>" data-r="<?php echo $r; ?>" data-c="<?php echo $c; ?>"></div>
                    <?php endfor; endfor; ?>
                </div>
                <div class="g24-sb-legend"><span class="g24-leg-hit"></span>Попал <span class="g24-leg-miss"></span>Промах</div>
            </div>
        </div>

        <div class="g24-sb-game-actions">
            <button class="g24-sb-surrender-btn" id="g24-sb-surrender">🏳️ Сдаться</button>
            <div id="g24-sb-msg" class="g24-sb-msg" style="display:none;"></div>
        </div>
    </div>

    <!-- GAME OVER SCREEN -->
    <div class="g24-sb-result" id="g24-sb-result" style="display:none;">
        <div class="g24-sb-result-icon" id="g24-sb-result-icon"></div>
        <div class="g24-sb-result-text" id="g24-sb-result-text"></div>
        <div class="g24-sb-result-payout" id="g24-sb-result-payout"></div>
        <button class="g24-sb-start-btn" id="g24-sb-play-again">🔄 Играть снова</button>
    </div>

</div>

  <!-- DEPOSIT MODAL -->
  <div class="g24-modal-overlay" id="g24-dep-modal-overlay" style="display:none;">
      <div class="g24-modal">
          <div class="g24-modal-header">
              <h3>💰 Пополнение баланса</h3>
              <button class="g24-modal-close g24-dep-modal-close">✕</button>
          </div>
          <div class="g24-modal-body">
              <div class="g24-modal-card-info">
                  <strong>Реквизиты для оплаты:</strong><br>
                  <?php echo esc_html( $card_info ); ?>
              </div>
              <div class="g24-form-group">
                  <label>Сумма пополнения (BYN)</label>
                  <input type="number" id="g24-dep-amount" class="g24-input" min="1" step="0.01" placeholder="Введите сумму">
              </div>
              <div class="g24-form-group">
                  <label>Подтверждение оплаты (номер транзакции / скриншот описание)</label>
                  <textarea id="g24-dep-info" class="g24-textarea" placeholder="Например: перевод от 15.05 на сумму 50 BYN, ссылка на чек" rows="3"></textarea>
              </div>
              <div id="g24-dep-msg" style="display:none;"></div>
          </div>
          <div class="g24-modal-footer">
              <button class="g24-btn-cancel g24-dep-modal-close">Отмена</button>
              <button class="g24-btn-submit" id="g24-dep-submit">Отправить заявку</button>
          </div>
      </div>
  </div>

  <script>
  (function($){
      $(document).ready(function(){
          $(document).on('click','.g24-open-deposit',function(){
              $('#g24-dep-modal-overlay').fadeIn(200);
              $('#g24-dep-msg').hide().text('').attr('class','');
          });
          $(document).on('click','.g24-dep-modal-close',function(){
              $('#g24-dep-modal-overlay').fadeOut(200);
          });
          $('#g24-dep-modal-overlay').on('click',function(e){
              if($(e.target).is('#g24-dep-modal-overlay'))$(this).fadeOut(200);
          });
          $('#g24-dep-submit').on('click',function(){
              var amount=$('#g24-dep-amount').val();
              var info=$.trim($('#g24-dep-info').val());
              var $msg=$('#g24-dep-msg');
              if(!amount||parseFloat(amount)<1){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Минимум 1 BYN');return;}
              if(!info){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Укажите подтверждение оплаты');return;}
              var $btn=$(this).prop('disabled',true).text('Отправка...');
              $.ajax({
                  url:g24Casino.ajaxUrl,type:'POST',
                  data:{action:'g24_deposit_request',nonce:g24Casino.nonce,amount:amount,payment_info:info},
                  success:function(r){
                      if(r.success){
                          $msg.show().attr('class','g24-wd-msg g24-wd-ok').text('✅ Заявка принята! Баланс пополнится после проверки платежа.');
                          $('#g24-dep-amount,#g24-dep-info').val('');
                          setTimeout(function(){$('#g24-dep-modal-overlay').fadeOut(200);},2800);
                      } else {
                          $msg.show().attr('class','g24-wd-msg g24-wd-error').text(r.data.message||'Ошибка');
                      }
                  },
                  error:function(){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Ошибка соединения');},
                  complete:function(){$btn.prop('disabled',false).text('Отправить заявку');}
              });
          });
      });
  })(jQuery);
  </script>
