<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * G24_CasinoHealth — гарантирует, что казино НИКОГДА не уходит в минус.
 *
 * Перед каждой выплатой вызывается can_payout($amount).
 * Если accumulated_profit < payout_amount → выплата запрещена, результат = проигрыш.
 * Прибыль кэшируется в wp_options и обновляется после каждой игры.
 */
class G24_CasinoHealth {

    const CACHE_KEY     = 'g24_house_profit_cache';
    const SAFETY_BUFFER = 0.00; // минимальный остаток прибыли, который нельзя тратить

    /* ── Пересчитать из БД и обновить кэш ─────────────────────────────────── */
    public static function recalculate_profit() {
        global $wpdb;
        $row = $wpdb->get_row(
            "SELECT COALESCE(SUM(bet_amount),0) AS bets,
                    COALESCE(SUM(payout),0)     AS payouts
             FROM {$wpdb->prefix}g24_games"
        );
        $profit = $row ? round( (float) $row->bets - (float) $row->payouts, 2 ) : 0.00;
        update_option( self::CACHE_KEY, $profit, false );
        return $profit;
    }

    /* ── Получить текущую прибыль (кэш → БД) ──────────────────────────────── */
    public static function get_house_profit() {
        $cached = get_option( self::CACHE_KEY, null );
        if ( $cached === null ) {
            return self::recalculate_profit();
        }
        return (float) $cached;
    }

    /* ── Обновить кэш после игры (инкрементально) ─────────────────────────── */
    public static function update_after_game( $bet_amount, $payout_amount ) {
        $current = self::get_house_profit();
        $new     = round( $current + (float) $bet_amount - (float) $payout_amount, 2 );
        update_option( self::CACHE_KEY, $new, false );
        return $new;
    }

    /* ── ГЛАВНАЯ ПРОВЕРКА: можно ли выплатить эту сумму? ──────────────────── */
    public static function can_payout( $payout_amount ) {
        $payout_amount = (float) $payout_amount;
        if ( $payout_amount <= 0 ) return true;

        $settings   = get_option( 'g24_casino_settings', [] );
        $protection = isset( $settings['profit_protection'] ) ? (int) $settings['profit_protection'] : 1;
        if ( ! $protection ) return true; // защита отключена администратором

        $profit = self::get_house_profit();
        return ( $profit - $payout_amount ) >= self::SAFETY_BUFFER;
    }

    /* ── Статус казино ─────────────────────────────────────────────────────── */
    public static function get_status() {
        $profit = self::get_house_profit();
        if ( $profit < 0   ) return 'DANGER';
        if ( $profit < 50  ) return 'WARNING';
        return 'OK';
    }

    /* ── Данные для дашборда ───────────────────────────────────────────────── */
    public static function get_dashboard() {
        global $wpdb;

        $all = $wpdb->get_row(
            "SELECT COALESCE(SUM(bet_amount),0) AS bets,
                    COALESCE(SUM(payout),0)     AS payouts,
                    COUNT(*)                    AS games,
                    SUM(result='win')           AS wins
             FROM {$wpdb->prefix}g24_games"
        );

        $today = current_time( 'Y-m-d' );
        $day   = $wpdb->get_row( $wpdb->prepare(
            "SELECT COALESCE(SUM(bet_amount),0) AS bets,
                    COALESCE(SUM(payout),0)     AS payouts,
                    COUNT(*)                    AS games
             FROM {$wpdb->prefix}g24_games
             WHERE DATE(created_at) = %s",
            $today
        ) );

        $profit_all  = round( (float) $all->bets - (float) $all->payouts, 2 );
        $profit_day  = round( (float) $day->bets - (float) $day->payouts, 2 );
        $win_pct     = $all->games > 0
                       ? round( (float) $all->wins / (float) $all->games * 100, 1 )
                       : 0;

        $dep_received = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}g24_deposits WHERE status='approved'"
        );
        $wdraw_paid = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}g24_withdrawals WHERE status='approved'"
        );

        return [
            'status'          => self::get_status(),
            'profit_all_time' => $profit_all,
            'profit_today'    => $profit_day,
            'total_bets'      => (float) $all->bets,
            'total_payouts'   => (float) $all->payouts,
            'total_games'     => (int)   $all->games,
            'win_pct'         => $win_pct,
            'dep_received'    => $dep_received,
            'wdraw_paid'      => $wdraw_paid,
            'cash_flow'       => round( $dep_received - $wdraw_paid, 2 ),
        ];
    }
}
