<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', 'g24_casino_admin_menu' );
function g24_casino_admin_menu() {
    $wd_pending  = G24_Withdrawals::count_pending();
    $dep_pending = G24_Deposits::count_pending();
    $total_pend  = $wd_pending + $dep_pending;
    $badge       = $total_pend ? ' <span class="awaiting-mod">' . $total_pend . '</span>' : '';

    add_menu_page( 'GOROD24 Casino', 'Casino 🎰', 'manage_options', 'g24-casino', 'g24_page_balances', 'dashicons-money-alt', 30 );
    add_submenu_page( 'g24-casino', 'Балансы',       'Балансы',                'manage_options', 'g24-casino',              'g24_page_balances' );
    add_submenu_page( 'g24-casino', 'Вывод средств', 'Вывод' . ( $wd_pending  ? ' <span class="awaiting-mod">'.$wd_pending.'</span>'  : '' ), 'manage_options', 'g24-casino-withdrawals', 'g24_page_withdrawals' );
    add_submenu_page( 'g24-casino', 'Пополнения',    'Пополнения' . ( $dep_pending ? ' <span class="awaiting-mod">'.$dep_pending.'</span>' : '' ), 'manage_options', 'g24-casino-deposits',    'g24_page_deposits' );
    add_submenu_page( 'g24-casino', 'Статистика',    'Статистика',             'manage_options', 'g24-casino-stats',        'g24_page_stats' );
    add_submenu_page( 'g24-casino', 'Транзакции',    'Транзакции',             'manage_options', 'g24-casino-transactions', 'g24_page_transactions' );
    add_submenu_page( 'g24-casino', 'Настройки',     'Настройки',              'manage_options', 'g24-casino-settings',     'g24_page_settings' );
}

add_action( 'admin_enqueue_scripts', 'g24_admin_scripts' );
function g24_admin_scripts( $hook ) {
    if ( strpos( $hook, 'g24-casino' ) === false ) return;
    wp_enqueue_style(  'g24-admin-css', G24_CASINO_URL . 'assets/css/admin.css', [], G24_CASINO_VERSION );
    wp_enqueue_script( 'g24-admin-js',  G24_CASINO_URL . 'assets/js/admin.js',  ['jquery'], G24_CASINO_VERSION, true );
    wp_localize_script( 'g24-admin-js', 'g24Admin', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'g24_admin_nonce' ),
    ] );
}

/* ═══════════════════════════════════════
   PAGE: BALANCES
═══════════════════════════════════════ */
function g24_page_balances() {
    $users  = G24_Balance::get_all_balances();
    $health = G24_CasinoHealth::get_dashboard();
    $status_color = ['OK'=>'#2ecc71','WARNING'=>'#f39c12','DANGER'=>'#e74c3c'][$health['status']] ?? '#aaa';
    $status_label = ['OK'=>'✅ В плюсе','WARNING'=>'⚠️ Почти ноль','DANGER'=>'🚨 ОПАСНО'][$health['status']] ?? '—';
    ?>
    <div class="wrap g24-admin-wrap">
        <h1>🎰 Casino — Управление балансами</h1>

        <!-- Casino health banner -->
        <div style="background:<?php echo $status_color; ?>22;border:2px solid <?php echo $status_color; ?>;border-radius:10px;padding:12px 18px;margin-bottom:18px;display:flex;gap:24px;flex-wrap:wrap;align-items:center;">
            <strong style="color:<?php echo $status_color; ?>;font-size:16px;"><?php echo $status_label; ?></strong>
            <span>Прибыль (всё время): <strong style="color:<?php echo $health['profit_all_time']>=0?'#2ecc71':'#e74c3c'; ?>"><?php echo number_format($health['profit_all_time'],2,'.',' '); ?> BYN</strong></span>
            <span>Сегодня: <strong><?php echo number_format($health['profit_today'],2,'.',' '); ?> BYN</strong></span>
            <span>Всего игр: <strong><?php echo $health['total_games']; ?></strong></span>
            <span>% выигрышей: <strong><?php echo $health['win_pct']; ?>%</strong></span>
        </div>

        <div class="g24-admin-grid">
            <div class="g24-admin-card">
                <h2>Пополнить / Списать баланс</h2>
                <div class="g24-form-row">
                    <label>Пользователь</label>
                    <select id="g24-admin-user" class="g24-admin-select">
                        <option value="">— Выберите —</option>
                        <?php foreach ( $users as $u ) :
                            $phone = get_user_meta($u->ID,'g24_phone',true);
                        ?>
                        <option value="<?php echo esc_attr($u->ID); ?>" data-balance="<?php echo esc_attr($u->balance); ?>">
                            <?php echo esc_html($u->display_name); ?>
                            <?php if ($phone) echo '(' . esc_html($phone) . ')'; ?>
                            — <?php echo esc_html(number_format($u->balance,2,'.',' ')); ?> BYN
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="g24-form-row" id="g24-cur-bal-row" style="display:none;">
                    <label>Текущий баланс</label>
                    <strong id="g24-cur-bal">0.00 BYN</strong>
                </div>
                <div class="g24-form-row">
                    <label>Сумма (BYN)</label>
                    <input type="number" id="g24-admin-amount" class="regular-text" min="0.01" step="0.01" placeholder="100.00">
                </div>
                <div class="g24-form-row">
                    <label>Комментарий</label>
                    <input type="text" id="g24-admin-desc" class="regular-text" value="Пополнение администратором">
                </div>
                <div class="g24-form-actions">
                    <button class="button button-primary" id="g24-btn-add">+ Пополнить</button>
                    <button class="button g24-btn-red" id="g24-btn-deduct">− Списать</button>
                </div>
                <div class="g24-quick-amounts">
                    <?php foreach ([10,20,50,100,200,500] as $a): ?>
                    <button class="button g24-quick-amt" data-amount="<?php echo $a; ?>"><?php echo $a; ?> BYN</button>
                    <?php endforeach; ?>
                </div>
                <div id="g24-admin-msg" class="g24-admin-msg" style="display:none;"></div>
            </div>

            <div class="g24-admin-card">
                <h2>Быстрые ссылки</h2>
                <p><a href="<?php echo admin_url('admin.php?page=g24-casino-deposits'); ?>" class="button button-primary">
                    💳 Заявки на пополнение (<?php echo G24_Deposits::count_pending(); ?>)
                </a></p>
                <p><a href="<?php echo admin_url('admin.php?page=g24-casino-withdrawals'); ?>" class="button">
                    💸 Заявки на вывод (<?php echo G24_Withdrawals::count_pending(); ?>)
                </a></p>
                <p><a href="<?php echo admin_url('admin.php?page=g24-casino-stats'); ?>" class="button">
                    📊 Статистика
                </a></p>
                <p><a href="<?php echo admin_url('admin.php?page=g24-casino-settings'); ?>" class="button">
                    ⚙️ Настройки
                </a></p>
                <hr>
                <h2>Инструкция</h2>
                <ol class="g24-instruction">
                    <li>Пользователь переводит деньги на вашу карту</li>
                    <li>Заявка на пополнение появится в разделе «Пополнения»</li>
                    <li>Одобрите — баланс пополнится автоматически</li>
                </ol>
            </div>
        </div>

        <div class="g24-admin-card">
            <h2>Все пользователи</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Имя</th><th>Email</th><th>Телефон</th><th>Реф.</th><th>Баланс</th><th>Действие</th></tr></thead>
                <tbody>
                    <?php foreach ($users as $u):
                        $phone  = get_user_meta($u->ID,'g24_phone',true);
                        $refs   = (int) get_user_meta($u->ID,'g24_referrals_count',true);
                    ?>
                    <tr>
                        <td><?php echo esc_html($u->display_name); ?></td>
                        <td><?php echo esc_html($u->user_email); ?></td>
                        <td><?php echo $phone ? esc_html($phone) : '<span style="color:#aaa">—</span>'; ?></td>
                        <td><?php echo $refs ? "<strong>{$refs}</strong>" : '<span style="color:#aaa">0</span>'; ?></td>
                        <td class="<?php echo $u->balance>0?'g24-positive':''; ?>">
                            <strong><?php echo esc_html(number_format($u->balance,2,'.',' ')); ?></strong> BYN
                        </td>
                        <td>
                            <button class="button button-small g24-inline-add"
                                data-user-id="<?php echo esc_attr($u->ID); ?>"
                                data-name="<?php echo esc_attr($u->display_name); ?>">Пополнить</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

/* ═══════════════════════════════════════
   PAGE: WITHDRAWALS
═══════════════════════════════════════ */
function g24_page_withdrawals() {
    $filter   = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'pending';
    $items    = G24_Withdrawals::get_all_requests( $filter==='all' ? '' : $filter, 50, 0 );
    $statuses = ['pending'=>'⏳ Ожидающие','approved'=>'✅ Выплаченные','rejected'=>'❌ Отклонённые','all'=>'Все'];
    ?>
    <div class="wrap g24-admin-wrap">
        <h1>💸 Casino — Заявки на вывод средств</h1>
        <div class="g24-filter-tabs">
            <?php foreach ($statuses as $key => $label): ?>
            <a href="?page=g24-casino-withdrawals&status=<?php echo $key; ?>"
               class="button <?php echo $filter===$key?'button-primary':''; ?>"><?php echo $label; ?></a>
            <?php endforeach; ?>
        </div>
        <?php if (empty($items)): ?>
            <div class="g24-admin-card" style="margin-top:16px;"><p style="color:#aaa;">Заявок нет.</p></div>
        <?php else: ?>
        <table class="wp-list-table widefat fixed striped" style="margin-top:16px;">
            <thead><tr>
                <th width="40">ID</th><th>Пользователь</th><th>Телефон</th>
                <th>Сумма</th><th>Реквизиты</th><th>Дата</th><th>Статус</th>
                <?php if ($filter==='pending'||$filter==='all'): ?><th>Действия</th><?php endif; ?>
            </tr></thead>
            <tbody>
                <?php foreach ($items as $item):
                    $phone = get_user_meta($item->user_id,'g24_phone',true);
                    $badges = ['pending'=>'<span class="g24-badge g24-badge-orange">⏳ Ожидает</span>','approved'=>'<span class="g24-badge g24-badge-green">✅ Выплачено</span>','rejected'=>'<span class="g24-badge g24-badge-red">❌ Отклонено</span>'];
                ?>
                <tr id="g24-wd-row-<?php echo $item->id; ?>">
                    <td><?php echo esc_html($item->id); ?></td>
                    <td><strong><?php echo esc_html($item->display_name); ?></strong><br><small><?php echo esc_html($item->user_email); ?></small></td>
                    <td><?php echo $phone ? esc_html($phone) : '<span style="color:#aaa">—</span>'; ?></td>
                    <td><strong style="color:#0a6640;"><?php echo esc_html(number_format($item->amount,2,'.',' ')); ?> BYN</strong></td>
                    <td style="max-width:200px;word-break:break-all;"><?php echo esc_html($item->card_details); ?></td>
                    <td><?php echo esc_html(date_i18n('d.m.Y H:i',strtotime($item->created_at))); ?></td>
                    <td>
                        <?php echo $badges[$item->status] ?? esc_html($item->status); ?>
                        <?php if ($item->admin_note): ?><br><small style="color:#aaa;"><?php echo esc_html($item->admin_note); ?></small><?php endif; ?>
                    </td>
                    <?php if ($filter==='pending'||$filter==='all'): ?>
                    <td>
                        <?php if ($item->status==='pending'): ?>
                        <div class="g24-wd-actions" data-id="<?php echo esc_attr($item->id); ?>">
                            <input type="text" class="g24-note-input" placeholder="Примечание" style="width:100%;margin-bottom:4px;">
                            <button class="button button-primary button-small g24-approve-btn">✅ Выплачено</button>
                            <button class="button button-small g24-reject-btn" style="background:#d63638;color:#fff;border-color:#d63638;">❌ Отклонить</button>
                        </div>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}

/* ═══════════════════════════════════════
   PAGE: DEPOSITS
═══════════════════════════════════════ */
function g24_page_deposits() {
    $filter   = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'pending';
    $items    = G24_Deposits::get_all( $filter==='all' ? '' : $filter, 50 );
    $statuses = ['pending'=>'⏳ Ожидающие','approved'=>'✅ Зачислено','rejected'=>'❌ Отклонённые','all'=>'Все'];
    ?>
    <div class="wrap g24-admin-wrap">
        <h1>💳 Casino — Заявки на пополнение</h1>
        <p style="color:#555;">Пользователи отправляют деньги на ваши реквизиты и уведомляют вас здесь. Проверьте оплату и нажмите «Зачислить».</p>
        <div class="g24-filter-tabs">
            <?php foreach ($statuses as $key => $label): ?>
            <a href="?page=g24-casino-deposits&status=<?php echo $key; ?>"
               class="button <?php echo $filter===$key?'button-primary':''; ?>"><?php echo $label; ?></a>
            <?php endforeach; ?>
        </div>
        <?php if (empty($items)): ?>
            <div class="g24-admin-card" style="margin-top:16px;"><p style="color:#aaa;">Заявок нет.</p></div>
        <?php else: ?>
        <table class="wp-list-table widefat fixed striped" style="margin-top:16px;">
            <thead><tr>
                <th width="40">ID</th><th>Пользователь</th><th>Телефон</th>
                <th>Сумма</th><th>Подтверждение</th><th>Дата</th><th>Статус</th>
                <?php if ($filter==='pending'||$filter==='all'): ?><th>Действия</th><?php endif; ?>
            </tr></thead>
            <tbody>
                <?php foreach ($items as $item):
                    $badges = ['pending'=>'<span class="g24-badge g24-badge-orange">⏳ Ожидает</span>','approved'=>'<span class="g24-badge g24-badge-green">✅ Зачислено</span>','rejected'=>'<span class="g24-badge g24-badge-red">❌ Отклонено</span>'];
                ?>
                <tr id="g24-dep-row-<?php echo $item->id; ?>">
                    <td><?php echo esc_html($item->id); ?></td>
                    <td><strong><?php echo esc_html($item->display_name); ?></strong><br><small><?php echo esc_html($item->user_email); ?></small></td>
                    <td><?php echo isset($item->phone) ? esc_html($item->phone) : '<span style="color:#aaa">—</span>'; ?></td>
                    <td><strong style="color:#0a6640;"><?php echo esc_html(number_format($item->amount,2,'.',' ')); ?> BYN</strong></td>
                    <td style="max-width:200px;word-break:break-all;"><?php echo esc_html($item->payment_info); ?></td>
                    <td><?php echo esc_html(date_i18n('d.m.Y H:i',strtotime($item->created_at))); ?></td>
                    <td>
                        <?php echo $badges[$item->status] ?? esc_html($item->status); ?>
                        <?php if ($item->admin_note): ?><br><small style="color:#aaa;"><?php echo esc_html($item->admin_note); ?></small><?php endif; ?>
                    </td>
                    <?php if ($filter==='pending'||$filter==='all'): ?>
                    <td>
                        <?php if ($item->status==='pending'): ?>
                        <div class="g24-dep-actions" data-id="<?php echo esc_attr($item->id); ?>">
                            <input type="text" class="g24-note-input" placeholder="Примечание" style="width:100%;margin-bottom:4px;">
                            <button class="button button-primary button-small g24-dep-approve-btn">✅ Зачислить</button>
                            <button class="button button-small g24-dep-reject-btn" style="background:#d63638;color:#fff;border-color:#d63638;">❌ Отклонить</button>
                        </div>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}

/* ═══════════════════════════════════════
   PAGE: STATS
═══════════════════════════════════════ */
function g24_page_stats() {
    $health = G24_CasinoHealth::get_dashboard();
    $status_color = ['OK'=>'#2ecc71','WARNING'=>'#f39c12','DANGER'=>'#e74c3c'][$health['status']] ?? '#aaa';
    global $wpdb;
    $top = $wpdb->get_results(
        "SELECT u.display_name, u.user_email,
         COALESCE((SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id=g.user_id AND meta_key='g24_phone' LIMIT 1),'—') AS phone,
         SUM(g.payout) AS total_won, COUNT(*) AS games
         FROM {$wpdb->prefix}g24_games g
         JOIN {$wpdb->users} u ON g.user_id=u.ID
         WHERE g.result='win'
         GROUP BY g.user_id ORDER BY total_won DESC LIMIT 10"
    );
    ?>
    <div class="wrap g24-admin-wrap">
        <h1>📊 Casino — Статистика</h1>

        <!-- Profit protection status -->
        <div style="background:<?php echo $status_color; ?>22;border:2px solid <?php echo $status_color; ?>;border-radius:10px;padding:14px 18px;margin-bottom:20px;">
            <h2 style="margin:0 0 10px;color:<?php echo $status_color; ?>;">
                Статус казино: <?php echo ['OK'=>'✅ Прибыльное','WARNING'=>'⚠️ Почти на нуле','DANGER'=>'🚨 В УБЫТКЕ'][$health['status']]; ?>
            </h2>
            <p style="margin:0;font-size:13px;">
                Защита прибыли: <strong>ВКЛЮЧЕНА</strong> — казино никогда не выплатит больше, чем заработало.
                <?php if ($health['status']==='DANGER'): ?>
                <br><strong style="color:#e74c3c;">⚠️ Срочно: пополните банк казино через раздел «Балансы»!</strong>
                <?php elseif ($health['status']==='WARNING'): ?>
                <br><em style="color:#f39c12;">Рекомендуется пополнить банк казино для бесперебойной работы.</em>
                <?php endif; ?>
            </p>
        </div>

        <div class="g24-stats-grid">
            <div class="g24-stat-card">
                <div class="g24-stat-num"><?php echo esc_html($health['total_games']); ?></div>
                <div class="g24-stat-label">Всего игр</div>
            </div>
            <div class="g24-stat-card">
                <div class="g24-stat-num"><?php echo esc_html(number_format($health['total_bets'],2,'.',' ')); ?> BYN</div>
                <div class="g24-stat-label">Сумма ставок</div>
            </div>
            <div class="g24-stat-card">
                <div class="g24-stat-num"><?php echo esc_html(number_format($health['total_payouts'],2,'.',' ')); ?> BYN</div>
                <div class="g24-stat-label">Выплачено игрокам</div>
            </div>
            <div class="g24-stat-card g24-profit-card" style="border-color:<?php echo $status_color; ?>;">
                <div class="g24-stat-num" style="color:<?php echo $status_color; ?>;"><?php echo esc_html(number_format($health['profit_all_time'],2,'.',' ')); ?> BYN</div>
                <div class="g24-stat-label">Прибыль казино</div>
            </div>
            <div class="g24-stat-card">
                <div class="g24-stat-num"><?php echo esc_html($health['win_pct']); ?>%</div>
                <div class="g24-stat-label">% выигрышей</div>
            </div>
            <div class="g24-stat-card">
                <div class="g24-stat-num"><?php echo esc_html(number_format($health['profit_today'],2,'.',' ')); ?> BYN</div>
                <div class="g24-stat-label">Прибыль сегодня</div>
            </div>
            <div class="g24-stat-card">
                <div class="g24-stat-num"><?php echo esc_html(number_format($health['dep_received'],2,'.',' ')); ?> BYN</div>
                <div class="g24-stat-label">Пополнений получено</div>
            </div>
            <div class="g24-stat-card">
                <div class="g24-stat-num"><?php echo esc_html(number_format($health['wdraw_paid'],2,'.',' ')); ?> BYN</div>
                <div class="g24-stat-label">Выводов выплачено</div>
            </div>
        </div>

        <div class="g24-admin-card" style="margin-top:20px;">
            <h2>Топ победителей</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Игрок</th><th>Телефон</th><th>Игр</th><th>Выиграно (BYN)</th></tr></thead>
                <tbody>
                    <?php if (empty($top)): ?>
                    <tr><td colspan="4" style="color:#aaa;">Данных нет</td></tr>
                    <?php else: foreach ($top as $w): ?>
                    <tr>
                        <td><?php echo esc_html($w->display_name); ?><br><small><?php echo esc_html($w->user_email); ?></small></td>
                        <td><?php echo esc_html($w->phone); ?></td>
                        <td><?php echo esc_html($w->games); ?></td>
                        <td class="g24-positive"><strong><?php echo esc_html(number_format($w->total_won,2,'.',' ')); ?></strong></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

/* ═══════════════════════════════════════
   PAGE: TRANSACTIONS
═══════════════════════════════════════ */
function g24_page_transactions() {
    global $wpdb;
    $page  = max(1,(int)($_GET['paged']??1));
    $pp    = 30;
    $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}g24_transactions");
    $items = $wpdb->get_results($wpdb->prepare(
        "SELECT t.*, u.display_name FROM {$wpdb->prefix}g24_transactions t
         LEFT JOIN {$wpdb->users} u ON t.user_id=u.ID
         ORDER BY t.created_at DESC LIMIT %d OFFSET %d",
        $pp, ($page-1)*$pp
    ));
    $tl = ['deposit'=>'<span class="g24-badge g24-badge-green">Пополнение</span>','debit'=>'<span class="g24-badge g24-badge-gray">Списание</span>','win'=>'<span class="g24-badge g24-badge-blue">Выигрыш</span>'];
    ?>
    <div class="wrap g24-admin-wrap">
        <h1>📋 Casino — Транзакции <span style="font-size:14px;color:#aaa;">(всего: <?php echo $total; ?>)</span></h1>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>ID</th><th>Дата</th><th>Пользователь</th><th>Тип</th><th>Сумма</th><th>До</th><th>После</th><th>Описание</th></tr></thead>
            <tbody>
                <?php foreach ($items as $it): ?>
                <tr>
                    <td><?php echo esc_html($it->id); ?></td>
                    <td><?php echo esc_html(date_i18n('d.m.Y H:i',strtotime($it->created_at))); ?></td>
                    <td><?php echo esc_html($it->display_name??'—'); ?></td>
                    <td><?php echo $tl[$it->type]??esc_html($it->type); ?></td>
                    <td><strong><?php echo esc_html(number_format($it->amount,2,'.',' ')); ?></strong></td>
                    <td><?php echo esc_html(number_format($it->balance_before,2,'.',' ')); ?></td>
                    <td><?php echo esc_html(number_format($it->balance_after,2,'.',' ')); ?></td>
                    <td><?php echo esc_html($it->description); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $pages=ceil($total/$pp);
        if ($pages>1) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(['base'=>add_query_arg('paged','%#%'),'format'=>'','total'=>$pages,'current'=>$page,'prev_text'=>'&laquo;','next_text'=>'&raquo;']);
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}

/* ═══════════════════════════════════════
   PAGE: SETTINGS
═══════════════════════════════════════ */
function g24_page_settings() {
    $s = get_option('g24_casino_settings',[
        'win_rate'=>48,'min_bet'=>0.10,'max_bet'=>1000,
        'card_info'=>'','deposit_info'=>'','play_page_url'=>'','profit_protection'=>1,
    ]);
    ?>
    <div class="wrap g24-admin-wrap">
        <h1>⚙️ Casino — Настройки</h1>
        <div class="g24-admin-grid">

            <div class="g24-admin-card">
                <h2>Игровые параметры</h2>
                <table class="form-table">
                    <tr>
                        <th><label>% выигрышей игроков</label></th>
                        <td>
                            <div class="g24-slider-wrap">
                                <input type="range" id="g24s-win-rate" min="5" max="95" value="<?php echo esc_attr($s['win_rate']); ?>" class="g24-slider">
                                <span class="g24-slider-val" id="g24s-win-rate-val"><?php echo esc_html($s['win_rate']); ?>%</span>
                            </div>
                            <p class="description">Рекомендуется: 35–48%. Честная рулетка: 48.6%.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Минимальная ставка (BYN)</label></th>
                        <td><input type="number" id="g24s-min-bet" class="small-text" value="<?php echo esc_attr($s['min_bet']); ?>" min="0.10" step="0.10"></td>
                    </tr>
                    <tr>
                        <th><label>Максимальная ставка (BYN)</label></th>
                        <td><input type="number" id="g24s-max-bet" class="small-text" value="<?php echo esc_attr($s['max_bet']); ?>" min="1" step="1"></td>
                    </tr>
                    <tr>
                        <th><label>URL страницы с играми</label></th>
                        <td>
                            <input type="url" id="g24s-play-url" class="regular-text" value="<?php echo esc_url($s['play_page_url']??''); ?>" placeholder="https://example.com/games/">
                            <p class="description">Кнопка «Играть» в виджете будет вести на эту страницу.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="g24-admin-card">
                <h2>🛡️ Защита прибыли</h2>
                <label style="display:flex;align-items:center;gap:10px;font-size:15px;cursor:pointer;">
                    <input type="checkbox" id="g24s-protection" <?php checked(1,(int)($s['profit_protection']??1)); ?> style="width:18px;height:18px;">
                    <span>Казино никогда не уходит в минус</span>
                </label>
                <p class="description" style="margin-top:10px;">
                    Когда включено: перед каждой выплатой система проверяет,
                    что суммарная прибыль казино (все ставки − все выплаты) не станет отрицательной.
                    Если выплата невозможна — результат принудительно меняется на проигрыш.
                    <br><strong>Рекомендуется всегда держать включённым.</strong>
                </p>
                <div style="margin-top:12px;padding:10px;background:#f0fff4;border:1px solid #2ecc71;border-radius:8px;font-size:13px;">
                    Текущая прибыль казино:
                    <strong id="g24-live-profit">
                        <?php echo number_format(G24_CasinoHealth::get_house_profit(),2,'.',' '); ?> BYN
                    </strong>
                </div>
            </div>
        </div>

        <div class="g24-admin-card" style="margin-top:16px;">
            <h2>Реквизиты для оплаты</h2>
            <div class="g24-admin-grid">
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:6px;">Реквизиты для пополнения (показываются игрокам)</label>
                    <textarea id="g24s-deposit-info" rows="5" style="width:100%;padding:8px;" placeholder="Карта: XXXX XXXX XXXX XXXX&#10;Банк: Беларусбанк&#10;ЕРИП: Код 12345&#10;Получатель: Иван И."><?php echo esc_textarea($s['deposit_info']??$s['card_info']??''); ?></textarea>
                    <p class="description">Показывается в модальном окне «Пополнить» на сайте.</p>
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:6px;">Реквизиты для вывода (показываются в форме вывода)</label>
                    <textarea id="g24s-card-info" rows="5" style="width:100%;padding:8px;" placeholder="Карта: XXXX XXXX XXXX XXXX&#10;Банк: Беларусбанк"><?php echo esc_textarea($s['card_info']??''); ?></textarea>
                    <p class="description">Показывается игроку в форме заявки на вывод.</p>
                </div>
            </div>
        </div>

        <div class="g24-admin-card" style="margin-top:16px;">
            <div class="g24-win-preview">
                <strong>Математика:</strong>
                При вин-рейте <span id="prev-win"><?php echo esc_html($s['win_rate']); ?></span>%
                казино зарабатывает примерно <span id="prev-edge"><?php echo 100-$s['win_rate']; ?></span>% от оборота.
            </div>
        </div>

        <p style="margin-top:16px;">
            <button class="button button-primary" id="g24-save-settings" style="font-size:15px;padding:8px 24px;">
                💾 Сохранить настройки
            </button>
        </p>
        <div id="g24-settings-msg" class="g24-admin-msg" style="display:none;max-width:400px;margin-top:10px;"></div>
    </div>
    <?php
}
