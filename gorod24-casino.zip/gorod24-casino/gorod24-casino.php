<?php
/**
 * Plugin Name: GOROD24 Casino
 * Plugin URI:  https://gorod24.by
 * Description: Полное казино — рулетка, слоты, морской бой. Баланс, реферальная система, вывод/пополнение, защита прибыли.
 * Version:     3.0.0
 * Author:      GOROD24.BY
 * Text Domain: gorod24-casino
 * License:     GPL2
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'G24_CASINO_VERSION', '3.0.0' );
define( 'G24_CASINO_DIR',     plugin_dir_path( __FILE__ ) );
define( 'G24_CASINO_URL',     plugin_dir_url( __FILE__ ) );

/* ── Includes ─────────────────────────────────────────────────────────────── */
// Base classes first (no inter-dependencies)
require_once G24_CASINO_DIR . 'includes/class-balance.php';
require_once G24_CASINO_DIR . 'includes/class-casino-health.php'; // MUST be before game classes
require_once G24_CASINO_DIR . 'includes/class-withdrawals.php';
require_once G24_CASINO_DIR . 'includes/class-deposits.php';
require_once G24_CASINO_DIR . 'includes/class-registration.php';
require_once G24_CASINO_DIR . 'includes/class-referral.php';
// Game classes use G24_CasinoHealth — load after it
require_once G24_CASINO_DIR . 'includes/class-roulette.php';
require_once G24_CASINO_DIR . 'includes/class-slots.php';
require_once G24_CASINO_DIR . 'includes/class-seabattle.php';
require_once G24_CASINO_DIR . 'includes/ajax-handlers.php';
require_once G24_CASINO_DIR . 'admin/admin-page.php';

/* ── Activation ───────────────────────────────────────────────────────────── */
register_activation_hook( __FILE__, 'g24_casino_activate' );
function g24_casino_activate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}g24_transactions (
        id             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id        BIGINT(20) UNSIGNED NOT NULL,
        type           VARCHAR(20) NOT NULL,
        amount         DECIMAL(10,2) NOT NULL,
        balance_before DECIMAL(10,2) NOT NULL,
        balance_after  DECIMAL(10,2) NOT NULL,
        description    TEXT,
        created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset;" );

    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}g24_games (
        id             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id        BIGINT(20) UNSIGNED NOT NULL,
        bet_amount     DECIMAL(10,2) NOT NULL,
        bet_type       VARCHAR(50) NOT NULL,
        bet_value      VARCHAR(50) NOT NULL,
        winning_number INT(3) NOT NULL,
        result         VARCHAR(10) NOT NULL,
        payout         DECIMAL(10,2) NOT NULL,
        created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset;" );

    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}g24_withdrawals (
        id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id      BIGINT(20) UNSIGNED NOT NULL,
        amount       DECIMAL(10,2) NOT NULL,
        card_details TEXT NOT NULL,
        status       VARCHAR(20) NOT NULL DEFAULT 'pending',
        admin_note   TEXT,
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME,
        PRIMARY KEY (id), KEY user_id (user_id), KEY status (status)
    ) $charset;" );

    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}g24_deposits (
        id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id      BIGINT(20) UNSIGNED NOT NULL,
        amount       DECIMAL(10,2) NOT NULL,
        payment_info TEXT NOT NULL,
        status       VARCHAR(20) NOT NULL DEFAULT 'pending',
        admin_note   TEXT,
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME,
        PRIMARY KEY (id), KEY user_id (user_id), KEY status (status)
    ) $charset;" );

    if ( ! get_option( 'g24_casino_settings' ) ) {
        update_option( 'g24_casino_settings', [
            'win_rate'          => 48,
            'min_bet'           => 0.10,
            'max_bet'           => 1000.00,
            'card_info'         => '',
            'deposit_info'      => '',
            'play_page_url'     => '',
            'profit_protection' => 1,
        ] );
    }
}

/* ── Registration & referral hooks ───────────────────────────────────────── */
add_action( 'init', function() {
    G24_Registration::init();
    G24_Referral::store_ref_cookie();
} );

add_action( 'user_register', function( $user_id ) {
    G24_Referral::handle_registration( $user_id );
} );

/* ── Enqueue scripts & styles ────────────────────────────────────────────── */
add_action( 'wp_enqueue_scripts', 'g24_casino_enqueue_scripts' );
function g24_casino_enqueue_scripts() {
    if ( ! is_user_logged_in() ) return;

    $uid      = get_current_user_id();
    $settings = get_option( 'g24_casino_settings', [] );
    $balance  = G24_Balance::get_balance( $uid );
    $ref_code = G24_Referral::get_or_create_code( $uid );
    $ref_link = G24_Referral::get_link( $uid );
    $ref_stats= G24_Referral::get_stats( $uid );
    $card_info= $settings['card_info']    ?? '';
    $dep_info = $settings['deposit_info'] ?? $card_info;

    // Styles
    wp_enqueue_style( 'g24-widget',     G24_CASINO_URL . 'assets/css/balance-widget.css', [], G24_CASINO_VERSION );
    wp_enqueue_style( 'g24-roulette',   G24_CASINO_URL . 'assets/css/roulette.css',       [], G24_CASINO_VERSION );
    wp_enqueue_style( 'g24-slots',      G24_CASINO_URL . 'assets/css/slots.css',          [], G24_CASINO_VERSION );
    wp_enqueue_style( 'g24-seabattle',  G24_CASINO_URL . 'assets/css/seabattle.css',      [], G24_CASINO_VERSION );

    // Scripts (jQuery dependent)
    wp_enqueue_script( 'g24-roulette',  G24_CASINO_URL . 'assets/js/roulette.js',       ['jquery'], G24_CASINO_VERSION, true );
    wp_enqueue_script( 'g24-slots',     G24_CASINO_URL . 'assets/js/slots.js',          ['jquery'], G24_CASINO_VERSION, true );
    wp_enqueue_script( 'g24-seabattle', G24_CASINO_URL . 'assets/js/seabattle.js',      ['jquery'], G24_CASINO_VERSION, true );
    wp_enqueue_script( 'g24-widget',    G24_CASINO_URL . 'assets/js/widget.js',         ['jquery'], G24_CASINO_VERSION, true );

    $username = wp_get_current_user()->display_name;

    wp_localize_script( 'g24-widget', 'g24Casino', [
        'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
        'nonce'        => wp_create_nonce( 'g24_casino_nonce' ),
        'userId'       => $uid,
        'balance'      => $balance,
        'username'     => $username,
        'currency'     => 'BYN',
        'minBet'       => $settings['min_bet'] ?? 0.10,
        'maxBet'       => $settings['max_bet'] ?? 1000.00,
        'playPageUrl'  => $settings['play_page_url'] ?? home_url('/'),
        'depositInfo'  => $dep_info,
        'refCode'      => $ref_code,
        'refLink'      => $ref_link,
        'refCount'     => $ref_stats['count'],
        'refEarned'    => $ref_stats['earned'],
        'refBonus'     => G24_Referral::BONUS_REFERRER,
        'refBonusNew'  => G24_Referral::BONUS_INVITED,
        'siteName'     => get_bloginfo('name'),
    ] );
}

/* ── Footer widget ───────────────────────────────────────────────────────── */
add_action( 'wp_footer', 'g24_balance_footer_widget' );
function g24_balance_footer_widget() {
    if ( ! is_user_logged_in() ) return;
    $uid      = get_current_user_id();
    $balance  = G24_Balance::get_balance( $uid );
    $username = wp_get_current_user()->display_name;
    $settings = get_option( 'g24_casino_settings', [] );
    $play_url = ! empty( $settings['play_page_url'] ) ? $settings['play_page_url'] : home_url( '/' );
    ?>
    <div id="g24-balance-widget" class="g24-balance-widget">
        <div class="g24-bw-inner">
            <span class="g24-bw-icon">🎰</span>
            <div class="g24-bw-info">
                <span class="g24-bw-name"><?php echo esc_html( $username ); ?></span>
                <span class="g24-bw-balance" id="g24-widget-balance">
                    <?php echo esc_html( number_format( $balance, 2, '.', ' ' ) ); ?> BYN
                </span>
            </div>
            <button class="g24-bw-deposit" id="g24-bw-deposit-btn" title="Пополнить баланс">+ Пополнить</button>
            <button class="g24-bw-invite"  id="g24-bw-invite-btn"  title="Пригласить друга">👥 Пригласить</button>
            <a href="<?php echo esc_url( $play_url ); ?>" class="g24-bw-play">Играть</a>
        </div>
    </div>

    <!-- Deposit modal -->
    <div class="g24-deposit-overlay" id="g24-deposit-overlay"></div>
    <div class="g24-deposit-modal" id="g24-deposit-modal" style="display:none;">
        <div class="g24-dm-header">
            <span class="g24-dm-title">💳 Пополнение баланса</span>
            <button class="g24-dm-close" id="g24-dm-close">✕</button>
        </div>
        <div class="g24-dm-body">
            <div class="g24-dm-step">
                <div class="g24-dm-step-title">Шаг 1 — Переведите деньги</div>
                <div class="g24-dm-payment-info" id="g24-dm-payment-info">
                    <?php
                    $info = ! empty( $settings['deposit_info'] ) ? $settings['deposit_info']
                                                                  : ( $settings['card_info'] ?? '—' );
                    echo esc_html( $info );
                    ?>
                </div>
                <button class="g24-dm-copy-btn" id="g24-dm-copy-btn">📋 Скопировать реквизиты</button>
            </div>
            <hr class="g24-dm-divider">
            <div class="g24-dm-step">
                <div class="g24-dm-step-title">Шаг 2 — Уведомите нас</div>
                <label class="g24-dm-label">Сумма пополнения (BYN)</label>
                <div class="g24-dm-quick-amts">
                    <?php foreach ( [10,20,50,100,200,500] as $a ) : ?>
                    <button class="g24-dm-quick" data-amount="<?php echo $a; ?>"><?php echo $a; ?></button>
                    <?php endforeach; ?>
                </div>
                <input type="number" id="g24-dm-amount" class="g24-dm-input" placeholder="Введите сумму" min="1" step="1">
                <label class="g24-dm-label">Подтверждение (номер чека, последние 4 цифры карты и т.д.)</label>
                <input type="text" id="g24-dm-info" class="g24-dm-input" placeholder="Напр.: чек #12345 или карта *7890">
                <button class="g24-dm-submit" id="g24-dm-submit">📨 Отправить заявку</button>
                <div class="g24-dm-msg" id="g24-dm-msg"></div>
            </div>
            <?php
            $history = G24_Deposits::get_user_requests( $uid, 5 );
            if ( $history ) :
            ?>
            <div class="g24-dm-history">
                <div class="g24-dm-history-title">Последние заявки</div>
                <?php foreach ( $history as $h ) :
                    $labels = ['pending'=>'Ожидание','approved'=>'Одобрено','rejected'=>'Отклонено'];
                ?>
                <div class="g24-dm-history-row">
                    <span><?php echo esc_html( date_i18n('d.m.Y', strtotime($h->created_at)) ); ?> — <?php echo esc_html(number_format($h->amount,2,'.',' ')); ?> BYN</span>
                    <span class="g24-dm-badge <?php echo esc_attr($h->status); ?>"><?php echo esc_html($labels[$h->status]??$h->status); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Invite / Referral modal -->
    <div class="g24-invite-overlay" id="g24-invite-overlay"></div>
    <div class="g24-invite-modal" id="g24-invite-modal" style="display:none;">
        <div class="g24-dm-header">
            <span class="g24-dm-title">👥 Пригласить друзей</span>
            <button class="g24-dm-close" id="g24-inv-close">✕</button>
        </div>
        <div class="g24-dm-body">
            <div class="g24-inv-bonuses">
                <div class="g24-inv-bonus-item">
                    <span class="g24-inv-bonus-icon">🎁</span>
                    <div>
                        <strong>Вы получаете</strong>
                        <span><?php echo number_format( G24_Referral::BONUS_REFERRER, 2 ); ?> BYN</span>
                    </div>
                </div>
                <div class="g24-inv-bonus-item">
                    <span class="g24-inv-bonus-icon">🎉</span>
                    <div>
                        <strong>Друг получает</strong>
                        <span><?php echo number_format( G24_Referral::BONUS_INVITED, 2 ); ?> BYN</span>
                    </div>
                </div>
            </div>

            <div class="g24-inv-stats">
                <?php $stats = G24_Referral::get_stats( $uid ); ?>
                <div class="g24-inv-stat">
                    <span class="g24-inv-stat-num"><?php echo $stats['count']; ?></span>
                    <span class="g24-inv-stat-lbl">Приглашено</span>
                </div>
                <div class="g24-inv-stat">
                    <span class="g24-inv-stat-num"><?php echo number_format($stats['earned'],2); ?></span>
                    <span class="g24-inv-stat-lbl">BYN заработано</span>
                </div>
            </div>

            <div class="g24-dm-step-title" style="margin-bottom:8px;">Ваша реферальная ссылка</div>
            <div class="g24-inv-link-row">
                <input type="text" class="g24-dm-input" id="g24-inv-link-input"
                       value="<?php echo esc_url( G24_Referral::get_link( $uid ) ); ?>" readonly>
                <button class="g24-dm-copy-btn" id="g24-inv-copy-link">📋 Копировать</button>
            </div>

            <div class="g24-dm-step-title" style="margin:14px 0 10px;">Поделиться в соцсетях</div>
            <div class="g24-inv-socials" id="g24-inv-socials">
                <!-- Filled by JS -->
            </div>
        </div>
    </div>
    <?php
}

/* ── Shortcodes ──────────────────────────────────────────────────────────── */
function g24_login_notice() {
    return '<div class="g24-casino-login-notice"><p>Для участия в игре необходимо <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">войти</a> на сайт.</p></div>';
}

add_shortcode( 'gorod24_roulette', function() {
    if ( ! is_user_logged_in() ) return g24_login_notice();
    ob_start();
    include G24_CASINO_DIR . 'includes/roulette-template.php';
    return ob_get_clean();
} );

add_shortcode( 'gorod24_slots', function() {
    if ( ! is_user_logged_in() ) return g24_login_notice();
    ob_start();
    include G24_CASINO_DIR . 'includes/slots-template.php';
    return ob_get_clean();
} );

add_shortcode( 'gorod24_seabattle', function() {
    if ( ! is_user_logged_in() ) return g24_login_notice();
    ob_start();
    include G24_CASINO_DIR . 'includes/seabattle-template.php';
    return ob_get_clean();
} );


  // Combined casino shortcode with game navigation
  function gorod24_casino_shortcode_combined($atts) {
      if (!is_user_logged_in()) {
          return '<div class="g24-casino-login-notice"><p>Пожалуйста, <a href="' . wp_login_url(get_permalink()) . '">войдите</a> чтобы играть.</p></div>';
      }
      $user_id = get_current_user_id();
      $balance = (float) get_user_meta($user_id, 'g24_casino_balance', true);
      ob_start();
      ?>
      <div class="g24-casino-nav-wrap">
          <div class="g24-game-nav">
              <button class="g24-game-tab active" onclick="g24SwitchGame(this,'roulette')">🎰 Рулетка</button>
              <button class="g24-game-tab" onclick="g24SwitchGame(this,'slots')">🎲 Слоты</button>
              <button class="g24-game-tab" onclick="g24SwitchGame(this,'seabattle')">⚓ Морской Бой</button>
          </div>
          <div id="g24-panel-roulette" class="g24-game-panel active">
              <?php echo do_shortcode('[gorod24_roulette]'); ?>
          </div>
          <div id="g24-panel-slots" class="g24-game-panel">
              <?php echo do_shortcode('[gorod24_slots]'); ?>
          </div>
          <div id="g24-panel-seabattle" class="g24-game-panel">
              <?php echo do_shortcode('[gorod24_seabattle]'); ?>
          </div>
      </div>
      <script>
      function g24SwitchGame(btn, panel) {
          document.querySelectorAll('.g24-game-tab').forEach(function(t){ t.classList.remove('active'); });
          document.querySelectorAll('.g24-game-panel').forEach(function(p){ p.classList.remove('active'); });
          btn.classList.add('active');
          document.getElementById('g24-panel-' + panel).classList.add('active');
      }
      </script>
      <?php
      return ob_get_clean();
  }
  add_shortcode('gorod24_casino', 'gorod24_casino_shortcode_combined');

  // ── Embed endpoint: serve standalone casino page at /?g24_embed=1 ──
  add_action( 'template_redirect', function() {
      if ( ! isset( $_GET['g24_embed'] ) ) return;
      // Load all plugin classes
      require_once G24_CASINO_PLUGIN_DIR . 'includes/class-balance.php';
      require_once G24_CASINO_PLUGIN_DIR . 'includes/class-roulette.php';
      require_once G24_CASINO_PLUGIN_DIR . 'includes/class-slots.php';
      require_once G24_CASINO_PLUGIN_DIR . 'includes/class-seabattle.php';
      require_once G24_CASINO_PLUGIN_DIR . 'includes/class-withdrawals.php';
      require_once G24_CASINO_PLUGIN_DIR . 'includes/roulette-template.php';
      // Serve the embed page
      require G24_CASINO_PLUGIN_DIR . 'includes/embed-page.php';
  } );

  // Allow embed iframe from any origin
  add_action( 'send_headers', function() {
      if ( isset( $_GET['g24_embed'] ) ) {
          header_remove( 'X-Frame-Options' );
          header( 'X-Frame-Options: ALLOWALL' );
      }
  } );
  
