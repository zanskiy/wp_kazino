/* GOROD24 Egyptian Slots JS */
(function($) {
    'use strict';

    var SYMBOLS = {
        pharaoh: { label:'👑', name:'Фараон',   cls:'g24-sym-wild'    },
        ra:      { label:'☀️', name:'Глаз Ра',  cls:'g24-sym-scatter' },
        scarab:  { label:'🪲', name:'Скарабей', cls:'' },
        ankh:    { label:'⚱️', name:'Анкх',     cls:'' },
        cat:     { label:'🐱', name:'Кошка',    cls:'' },
        gem:     { label:'💎', name:'Самоцвет', cls:'' },
        pyramid: { label:'🔺', name:'Пирамида', cls:'' },
        sand:    { label:'⌛', name:'Песок',    cls:'' },
    };
    var SYM_KEYS = Object.keys(SYMBOLS);

    var freeSpins   = 0;
    var isSpinning  = false;
    var lastReels   = null;

    function randSym() { return SYM_KEYS[Math.floor(Math.random() * SYM_KEYS.length)]; }

    function buildSymbolEl(key) {
        var s   = SYMBOLS[key];
        var div = document.createElement('div');
        div.className = 'g24-slot-symbol ' + s.cls;
        div.innerHTML = '<span>' + s.label + '</span><span class="g24-sym-lbl">' + s.name + '</span>';
        div.dataset.sym = key;
        return div;
    }

    function initReels() {
        for (var i = 0; i < 5; i++) {
            var inner = document.getElementById('g24-reel-inner-' + i);
            if (!inner) continue;
            inner.innerHTML = '';
            // 3 visible rows + extra rows for animation
            for (var r = 0; r < 8; r++) {
                inner.appendChild(buildSymbolEl(randSym()));
            }
        }
    }

    function setReelSymbols(reelIdx, topSym, midSym, botSym) {
        var inner = document.getElementById('g24-reel-inner-' + reelIdx);
        if (!inner) return;
        var children = inner.querySelectorAll('.g24-slot-symbol');
        // Slots at positions 0,1,2 are visible (top, mid, bot)
        if (children[0]) children[0].dataset.sym = topSym, children[0].querySelector('span').textContent = SYMBOLS[topSym].label, children[0].lastChild.textContent = SYMBOLS[topSym].name, children[0].className = 'g24-slot-symbol ' + SYMBOLS[topSym].cls;
        if (children[1]) children[1].dataset.sym = midSym, children[1].querySelector('span').textContent = SYMBOLS[midSym].label, children[1].lastChild.textContent = SYMBOLS[midSym].name, children[1].className = 'g24-slot-symbol ' + SYMBOLS[midSym].cls;
        if (children[2]) children[2].dataset.sym = botSym, children[2].querySelector('span').textContent = SYMBOLS[botSym].label, children[2].lastChild.textContent = SYMBOLS[botSym].name, children[2].className = 'g24-slot-symbol ' + SYMBOLS[botSym].cls;
    }

    function spinAnimation(serverReels, onDone) {
        var delays = [0, 200, 400, 600, 800]; // stagger per reel

        for (var i = 0; i < 5; i++) {
            (function(reelIdx) {
                var inner = document.getElementById('g24-reel-inner-' + reelIdx);
                if (!inner) return;

                // Start spinning animation
                setTimeout(function() {
                    inner.classList.add('spinning');
                }, delays[reelIdx]);

                // Stop after delay and show correct symbols
                var stopDelay = delays[reelIdx] + 1400 + reelIdx * 250;
                setTimeout(function() {
                    inner.classList.remove('spinning');
                    inner.style.transform = 'translateY(0)';
                    var reel = serverReels[reelIdx];
                    setReelSymbols(reelIdx, reel[0], reel[1], reel[2]);
                    if (reelIdx === 4) {
                        setTimeout(onDone, 200);
                    }
                }, stopDelay);
            })(i);
        }
    }

    function highlightWins(wins) {
        // Remove previous highlights
        document.querySelectorAll('.g24-winning').forEach(function(el) { el.classList.remove('g24-winning'); });

        var PAYLINE_ROWS = {
            'line1': [1,1,1,1,1],
            'line2': [0,0,0,0,0],
            'line3': [2,2,2,2,2],
            'line4': [0,1,2,1,0],
            'line5': [2,1,0,1,2],
        };

        wins.forEach(function(win) {
            if (win.line === 'scatter') return;
            var rows = PAYLINE_ROWS[win.line];
            if (!rows) return;
            for (var col = 0; col < win.count; col++) {
                var inner = document.getElementById('g24-reel-inner-' + col);
                if (!inner) continue;
                var cells = inner.querySelectorAll('.g24-slot-symbol');
                if (cells[rows[col]]) cells[rows[col]].classList.add('g24-winning');
            }
        });
    }

    function updateBalance(val) {
        var str = parseFloat(val).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
        $('#g24-slots-balance').text(str);
        $('#g24-widget-balance').text(str + ' BYN');
        if (typeof g24Casino !== 'undefined') g24Casino.balance = val;
    }

    function showWin(wins, mult, payout) {
        var $display = $('#g24-slots-win-display');
        var $label   = $('#g24-slots-win-label');
        if (mult > 0) {
            var msgs = wins.map(function(w) {
                if (w.line === 'scatter') return '☀️ SCATTER x' + w.mult;
                return SYMBOLS[w.symbol].label + ' ×' + w.count + ' → x' + w.mult;
            });
            $label.text(msgs.join('  |  ') + '  💰 +' + parseFloat(payout).toFixed(2) + ' BYN');
            $display.show();
        } else {
            $display.hide();
        }
    }

    function doSpin() {
        if (isSpinning) return;
        var bet = parseFloat($('#g24-slots-bet').val());
        if (!bet || bet <= 0) { alert('Введите сумму ставки'); return; }

        isSpinning = true;
        $('#g24-slots-spin').prop('disabled', true);
        $('#g24-slots-spin .g24-slots-spin-text').hide();
        $('#g24-slots-spin .g24-slots-spin-load').show();
        $('#g24-slots-win-display').hide();

        $.ajax({
            url:  g24Casino.ajaxUrl,
            type: 'POST',
            data: { action: 'g24_slots_spin', nonce: g24Casino.nonce, bet_amount: bet },
            success: function(resp) {
                if (!resp.success) {
                    alert(resp.data.message || 'Ошибка');
                    resetSpinBtn();
                    return;
                }
                var d = resp.data;
                lastReels = d.reels;

                spinAnimation(d.reels, function() {
                    highlightWins(d.wins);
                    showWin(d.wins, d.total_mult, d.payout);
                    updateBalance(d.new_balance);

                    if (d.free_spins > 0) {
                        freeSpins += d.free_spins;
                        $('#g24-free-spins-count').text(freeSpins);
                        $('#g24-free-spins-banner').show();
                    }

                    resetSpinBtn();

                    // Auto free spin
                    if (freeSpins > 0) {
                        freeSpins--;
                        $('#g24-free-spins-count').text(freeSpins);
                        if (freeSpins === 0) $('#g24-free-spins-banner').hide();
                        setTimeout(doSpin, 1000);
                    }
                });
            },
            error: function() { alert('Ошибка соединения'); resetSpinBtn(); }
        });
    }

    function resetSpinBtn() {
        isSpinning = false;
        $('#g24-slots-spin').prop('disabled', false);
        $('#g24-slots-spin .g24-slots-spin-text').show();
        $('#g24-slots-spin .g24-slots-spin-load').hide();
    }

    $(document).ready(function() {
        if (!$('#g24-slots').length) return;

        initReels();

        $('#g24-slots-spin').on('click', doSpin);

        $(document).on('click', '.g24-slots-quick', function() {
            var amt = parseFloat($(this).data('amount'));
            var bal = parseFloat(typeof g24Casino !== 'undefined' ? g24Casino.balance : 0);
            $('#g24-slots-bet').val(Math.min(amt, bal));
        });

        $('#g24-slots-rules-toggle').on('click', function() {
            var $txt = $('#g24-slots-rules-text');
            $txt.slideToggle(250);
            $(this).text($txt.is(':visible') ? '📖 Правила игры ▲' : '📖 Правила игры ▼');
        });
    });

})(jQuery);
