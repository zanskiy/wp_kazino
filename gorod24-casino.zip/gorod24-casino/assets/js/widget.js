/* GOROD24 Casino — Widget JS (deposit modal + invite modal) */
(function($) {
    'use strict';

    /* ── Helpers ────────────────────────────────────────────────────────────── */
    function openModal(overlay, modal) {
        $(overlay).fadeIn(200);
        $(modal).fadeIn(200);
        $('body').css('overflow', 'hidden');
    }
    function closeModal(overlay, modal) {
        $(overlay).fadeOut(200);
        $(modal).fadeOut(200);
        $('body').css('overflow', '');
    }
    function showMsg($el, text, type) {
        $el.attr('class', 'g24-dm-msg ' + type).text(text).show();
    }

    $(document).ready(function() {

        /* ── Deposit modal ────────────────────────────────────────────────── */
        $('#g24-bw-deposit-btn').on('click', function() {
            openModal('#g24-deposit-overlay', '#g24-deposit-modal');
        });
        $('#g24-dm-close, #g24-deposit-overlay').on('click', function() {
            closeModal('#g24-deposit-overlay', '#g24-deposit-modal');
        });

        // Quick amount buttons inside deposit modal
        $(document).on('click', '.g24-dm-quick', function() {
            $('#g24-dm-amount').val($(this).data('amount'));
        });

        // Copy payment requisites
        $('#g24-dm-copy-btn').on('click', function() {
            var text = $('#g24-dm-payment-info').text().trim();
            navigator.clipboard ? navigator.clipboard.writeText(text) :
                (function() { var ta = $('<textarea/>').val(text).appendTo('body').select(); document.execCommand('copy'); ta.remove(); })();
            $(this).text('✅ Скопировано!').addClass('copied');
            setTimeout(function() { $('#g24-dm-copy-btn').text('📋 Скопировать реквизиты').removeClass('copied'); }, 2000);
        });

        // Submit deposit request
        $('#g24-dm-submit').on('click', function() {
            var amount = parseFloat($('#g24-dm-amount').val());
            var info   = $('#g24-dm-info').val().trim();
            var $msg   = $('#g24-dm-msg');
            var $btn   = $(this);

            if (!amount || amount < 1) { showMsg($msg, 'Введите сумму от 1 BYN', 'error'); return; }
            if (!info)                 { showMsg($msg, 'Укажите подтверждение оплаты', 'error'); return; }

            $btn.prop('disabled', true).text('⏳ Отправляем...');

            $.post(
                (typeof g24Casino !== 'undefined' ? g24Casino.ajaxUrl : '/wp-admin/admin-ajax.php'),
                {
                    action:       'g24_deposit_request',
                    nonce:        g24Casino.nonce,
                    amount:       amount,
                    payment_info: info,
                },
                function(resp) {
                    if (resp.success) {
                        showMsg($msg, '✅ ' + resp.data.message, 'ok');
                        $('#g24-dm-amount').val('');
                        $('#g24-dm-info').val('');
                    } else {
                        showMsg($msg, '❌ ' + (resp.data ? resp.data.message : 'Ошибка'), 'error');
                    }
                }
            ).always(function() {
                $btn.prop('disabled', false).text('📨 Отправить заявку');
            });
        });

        /* ── Invite / Referral modal ─────────────────────────────────────── */
        $('#g24-bw-invite-btn').on('click', function() {
            buildSocialButtons();
            openModal('#g24-invite-overlay', '#g24-invite-modal');
        });
        $('#g24-inv-close, #g24-invite-overlay').on('click', function() {
            closeModal('#g24-invite-overlay', '#g24-invite-modal');
        });

        // Copy referral link
        $('#g24-inv-copy-link').on('click', function() {
            var link = $('#g24-inv-link-input').val();
            navigator.clipboard ? navigator.clipboard.writeText(link) :
                (function() { var ta = $('<textarea/>').val(link).appendTo('body').select(); document.execCommand('copy'); ta.remove(); })();
            $(this).text('✅ Скопировано!').addClass('copied');
            setTimeout(function() { $('#g24-inv-copy-link').text('📋 Копировать').removeClass('copied'); }, 2000);
        });

        function buildSocialButtons() {
            var $wrap = $('#g24-inv-socials');
            if ($wrap.children().length) return; // already built

            var c = typeof g24Casino !== 'undefined' ? g24Casino : {};
            var link     = encodeURIComponent(c.refLink || window.location.href);
            var siteName = c.siteName || 'Казино';
            var text     = encodeURIComponent('🎰 Играй в ' + siteName + ' и получай реальные деньги! Регистрация по моей ссылке — и тебе сразу +' + (c.refBonusNew || 2) + ' BYN на счёт!');

            var networks = [
                {
                    name:  'Telegram',
                    emoji: '✈️',
                    color: '#0088cc',
                    url:   'https://t.me/share/url?url=' + link + '&text=' + text,
                },
                {
                    name:  'ВКонтакте',
                    emoji: '🔵',
                    color: '#4680c2',
                    url:   'https://vk.com/share.php?url=' + link + '&title=' + text,
                },
                {
                    name:  'WhatsApp',
                    emoji: '💬',
                    color: '#25d366',
                    url:   'https://wa.me/?text=' + text + '%20' + link,
                },
                {
                    name:  'Viber',
                    emoji: '📲',
                    color: '#7360f2',
                    url:   'viber://forward?text=' + text + '%20' + link,
                },
                {
                    name:  'Одноклассники',
                    emoji: '🟠',
                    color: '#ee8208',
                    url:   'https://connect.ok.ru/offer?url=' + link + '&title=' + text,
                },
            ];

            networks.forEach(function(n) {
                var $btn = $('<a>', {
                    href:   n.url,
                    target: '_blank',
                    rel:    'noopener',
                    class:  'g24-social-btn',
                    html:   '<span>' + n.emoji + '</span><span>' + n.name + '</span>',
                }).css('background', n.color);
                $wrap.append($btn);
            });
        }

        /* ── Close modals on Escape ──────────────────────────────────────── */
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal('#g24-deposit-overlay', '#g24-deposit-modal');
                closeModal('#g24-invite-overlay',  '#g24-invite-modal');
            }
        });
    });

})(jQuery);
