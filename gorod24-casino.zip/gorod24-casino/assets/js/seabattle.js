/* GOROD24 Sea Battle JS */
(function($) {
    'use strict';

    var isWaiting = false;
    var myTurn    = true;

    function fmtBal(v) { return parseFloat(v).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }

    function updateBalance(v) {
        $('#g24-sb-balance').text(fmtBal(v));
        $('#g24-widget-balance').text(fmtBal(v) + ' BYN');
        if (typeof g24Casino !== 'undefined') g24Casino.balance = v;
    }

    function setTurn(mine) {
        myTurn = mine;
        var $t = $('#g24-sb-turn');
        if (mine) {
            $t.text('🎯 Ваш ход — выберите клетку на поле противника').css('color','#2196f3');
            $('#g24-sb-enemy-grid .g24-sb-clickable:not(.g24-sb-disabled)').css('pointer-events','auto');
        } else {
            $t.text('⏳ Противник думает...').css('color','#ffa726');
            $('#g24-sb-enemy-grid .g24-sb-clickable').css('pointer-events','none');
        }
    }

    function applyPlayerBoard(board) {
        var cells = $('#g24-sb-player-grid .g24-sb-cell');
        var idx   = 0;
        for (var r = 0; r < 10; r++) {
            for (var c = 0; c < 10; c++) {
                var $cell = cells.eq(idx++);
                $cell.removeClass('g24-sb-ship g24-sb-hit g24-sb-miss g24-sb-enemy-hit');
                var v = board[r][c];
                if (v === 1) $cell.addClass('g24-sb-ship');
                else if (v === 2) $cell.addClass('g24-sb-hit');
                else if (v === 3) $cell.addClass('g24-sb-miss');
            }
        }
    }

    function applyEnemyReveal(reveal) {
        var cells = $('#g24-sb-enemy-grid .g24-sb-cell');
        var idx   = 0;
        for (var r = 0; r < 10; r++) {
            for (var c = 0; c < 10; c++) {
                var $cell = cells.eq(idx++);
                var v = reveal[r][c];
                if (v === 2) { $cell.addClass('g24-sb-hit g24-sb-disabled').removeClass('g24-sb-clickable'); }
                else if (v === 3) { $cell.addClass('g24-sb-miss g24-sb-disabled').removeClass('g24-sb-clickable'); }
            }
        }
    }

    function showGameOver(won, payout, newBalance) {
        $('#g24-sb-game').hide();
        var $result = $('#g24-sb-result').show();
        if (won) {
            $('#g24-sb-result-icon').text('🏆');
            $('#g24-sb-result-text').text('ПОБЕДА!').addClass('g24-sb-result-win');
            $('#g24-sb-result-payout').text('Выплата: +' + fmtBal(payout) + ' BYN');
        } else {
            $('#g24-sb-result-icon').text('💀');
            $('#g24-sb-result-text').text('ПОРАЖЕНИЕ').addClass('g24-sb-result-loss');
            $('#g24-sb-result-payout').text('Ставка проиграна');
        }
        updateBalance(newBalance);
    }

    function startGame() {
        var bet = parseFloat($('#g24-sb-bet-input').val());
        if (!bet || bet <= 0) { alert('Введите сумму ставки'); return; }
        var $btn = $('#g24-sb-start-btn').prop('disabled', true).text('Загрузка...');
        var $msg = $('#g24-sb-start-msg');

        $.ajax({
            url: g24Casino.ajaxUrl, type: 'POST',
            data: { action: 'g24_seabattle_start', nonce: g24Casino.nonce, bet_amount: bet },
            success: function(resp) {
                if (!resp.success) {
                    $msg.show().attr('class', 'g24-sb-msg g24-sb-error').text(resp.data.message || 'Ошибка');
                    $btn.prop('disabled', false).text('⚓ НАЧАТЬ ИГРУ');
                    return;
                }
                var d = resp.data;
                updateBalance(d.new_balance);

                $('#g24-sb-start').hide();
                $('#g24-sb-result').hide();
                $('#g24-sb-game').show();

                $('#g24-sb-total').text(d.ships_total);
                $('#g24-sb-my-hits').text(0);
                $('#g24-sb-opp-hits').text(0);
                $('#g24-sb-current-bet').text(fmtBal(d.bet));

                // Rebuild grids
                rebuildGrid('#g24-sb-player-grid', false);
                rebuildGrid('#g24-sb-enemy-grid', true);
                applyPlayerBoard(d.player_board);

                myTurn = true;
                setTurn(true);
                $btn.prop('disabled', false).text('⚓ НАЧАТЬ ИГРУ');
            },
            error: function() { $msg.show().attr('class','g24-sb-msg g24-sb-error').text('Ошибка соединения'); $btn.prop('disabled',false).text('⚓ НАЧАТЬ ИГРУ'); }
        });
    }

    function rebuildGrid(selector, clickable) {
        var $grid = $(selector).empty();
        for (var r = 0; r < 10; r++) {
            for (var c = 0; c < 10; c++) {
                var $cell = $('<div class="g24-sb-cell" data-r="'+r+'" data-c="'+c+'"></div>');
                if (clickable) $cell.addClass('g24-sb-clickable');
                $grid.append($cell);
            }
        }
    }

    function shoot(row, col) {
        if (isWaiting || !myTurn) return;
        isWaiting = true;
        setTurn(false);

        $.ajax({
            url: g24Casino.ajaxUrl, type: 'POST',
            data: { action: 'g24_seabattle_shoot', nonce: g24Casino.nonce, row: row, col: col },
            success: function(resp) {
                isWaiting = false;
                if (!resp.success) { setTurn(true); alert(resp.data.message); return; }
                var d = resp.data;

                // Mark player's shot
                var $eCell = $('#g24-sb-enemy-grid .g24-sb-cell[data-r="'+d.player_row+'"][data-c="'+d.player_col+'"]');
                $eCell.removeClass('g24-sb-clickable').addClass('g24-sb-disabled');
                if (d.player_hit) {
                    $eCell.addClass('g24-sb-hit g24-sb-just-hit');
                } else {
                    $eCell.addClass('g24-sb-miss g24-sb-just-miss');
                }
                setTimeout(function() { $eCell.removeClass('g24-sb-just-hit g24-sb-just-miss'); }, 500);

                $('#g24-sb-my-hits').text(d.player_hits);
                $('#g24-sb-opp-hits').text(d.opponent_hits);

                if (d.game_over) {
                    if (!d.player_won) applyEnemyReveal(d.opponent_reveal);
                    setTimeout(function() { showGameOver(d.player_won, d.payout, d.new_balance); }, 600);
                    return;
                }

                // Opponent's shot with delay for drama
                if (d.opp_row !== null) {
                    setTimeout(function() {
                        var $pCell = $('#g24-sb-player-grid .g24-sb-cell[data-r="'+d.opp_row+'"][data-c="'+d.opp_col+'"]');
                        if (d.opp_hit) {
                            $pCell.addClass('g24-sb-hit g24-sb-enemy-hit');
                        } else {
                            $pCell.addClass('g24-sb-miss');
                        }
                        $('#g24-sb-opp-hits').text(d.opponent_hits);

                        if (d.game_over) {
                            setTimeout(function() { showGameOver(false, 0, d.new_balance); }, 600);
                        } else {
                            setTurn(true);
                        }
                    }, 800);
                } else {
                    // Player hit = shoot again
                    if (d.player_hit) {
                        setTurn(true);
                    }
                }
            },
            error: function() { isWaiting = false; setTurn(true); alert('Ошибка соединения'); }
        });
    }

    $(document).ready(function() {
        if (!$('#g24-seabattle').length) return;

        // Bet quick amounts
        $(document).on('click', '.g24-sb-quick', function() {
            var amt = parseFloat($(this).data('amount'));
            var bal = parseFloat(typeof g24Casino !== 'undefined' ? g24Casino.balance : 0);
            $('#g24-sb-bet-input').val(Math.min(amt, bal));
            $('#g24-sb-win-preview').text((Math.min(amt,bal)*2).toFixed(2) + ' BYN');
        });
        $('#g24-sb-bet-input').on('input', function() {
            var v = parseFloat($(this).val()) || 0;
            $('#g24-sb-win-preview').text((v*2).toFixed(2) + ' BYN');
        });

        // Start game
        $('#g24-sb-start-btn').on('click', startGame);

        // Shoot
        $(document).on('click', '#g24-sb-enemy-grid .g24-sb-clickable:not(.g24-sb-disabled)', function() {
            if (!myTurn || isWaiting) return;
            shoot($(this).data('r'), $(this).data('c'));
        });

        // Surrender
        $('#g24-sb-surrender').on('click', function() {
            if (!confirm('Сдаться? Ставка будет потеряна.')) return;
            $.post(g24Casino.ajaxUrl, { action:'g24_seabattle_surrender', nonce:g24Casino.nonce }, function(resp) {
                if (resp.success) {
                    if (resp.data.opponent_board) applyEnemyReveal(resp.data.opponent_board);
                    showGameOver(false, 0, typeof g24Casino !== 'undefined' ? g24Casino.balance : 0);
                }
            });
        });

        // Play again
        $('#g24-sb-play-again').on('click', function() {
            $('#g24-sb-result').hide();
            $('#g24-sb-result-text').removeClass('g24-sb-result-win g24-sb-result-loss');
            $('#g24-sb-start').show();
        });

        // Restore active game
        if ($('#g24-sb-game').is(':visible')) {
            setTurn(true);
        }
    });

})(jQuery);
