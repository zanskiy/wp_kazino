/* GOROD24 Casino Roulette v2.0 */
  (function($) {
      'use strict';

      var WHEEL_NUMS = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
      var RED_NUMS   = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
      var TOTAL      = 37;
      var SLICE_DEG  = 360 / TOTAL;
      var SIZE       = 320;
      var CX = SIZE/2, CY = SIZE/2;
      var OUTER_R = 152, INNER_R = 90;
      var BALL_R  = 7;

      var selectedBetType  = null;
      var selectedBetValue = null;
      var isSpinning       = false;
      var currentWheelDeg  = 0;

      function drawWheel() {
          var canvas = document.getElementById('g24-wheel-canvas');
          if (!canvas) return;
          var ctx = canvas.getContext('2d');
          ctx.clearRect(0, 0, SIZE, SIZE);

          /* PASS 1: segment fills only, no text */
          for (var i = 0; i < TOTAL; i++) {
              var num   = WHEEL_NUMS[i];
              var sa    = (i * SLICE_DEG - 90) * Math.PI / 180;
              var ea    = ((i+1) * SLICE_DEG - 90) * Math.PI / 180;
              ctx.beginPath(); ctx.moveTo(CX,CY);
              ctx.arc(CX,CY,OUTER_R,sa,ea); ctx.closePath();
              ctx.fillStyle = num===0 ? '#1b7b4b' : (RED_NUMS.indexOf(num)!==-1 ? '#c0392b' : '#1a1a2e');
              ctx.fill();
              ctx.strokeStyle='rgba(212,175,55,0.5)'; ctx.lineWidth=0.8; ctx.stroke();
          }

          /* Inner black circle — drawn BEFORE numbers so it never covers them */
          ctx.beginPath(); ctx.arc(CX,CY,INNER_R,0,Math.PI*2);
          ctx.fillStyle='#0d1117'; ctx.fill();
          ctx.strokeStyle='#d4af37'; ctx.lineWidth=2.5; ctx.stroke();

          /* Divider lines */
          for (var j=0;j<TOTAL;j++){
              var la=((j*SLICE_DEG)-90)*Math.PI/180;
              ctx.beginPath();
              ctx.moveTo(CX+(INNER_R+2)*Math.cos(la), CY+(INNER_R+2)*Math.sin(la));
              ctx.lineTo(CX+OUTER_R*Math.cos(la), CY+OUTER_R*Math.sin(la));
              ctx.strokeStyle='rgba(212,175,55,0.4)'; ctx.lineWidth=0.8; ctx.stroke();
          }

          /* Outer gold rim */
          ctx.beginPath(); ctx.arc(CX,CY,OUTER_R+5,0,Math.PI*2);
          ctx.strokeStyle='#d4af37'; ctx.lineWidth=9; ctx.stroke();

          /* PASS 2: number labels drawn ON TOP — never covered by inner circle */
          for (var k=0;k<TOTAL;k++){
              var n  = WHEEL_NUMS[k];
              var sa2= (k*SLICE_DEG-90)*Math.PI/180;
              var ea2= ((k+1)*SLICE_DEG-90)*Math.PI/180;
              var mid= sa2+(ea2-sa2)/2;
              var nr = INNER_R+(OUTER_R-INNER_R)*0.58;
              var tx = CX+nr*Math.cos(mid), ty=CY+nr*Math.sin(mid);
              ctx.save(); ctx.translate(tx,ty); ctx.rotate(mid+Math.PI/2);
              ctx.textAlign='center'; ctx.textBaseline='middle';
              ctx.font='bold 14px Arial, sans-serif';
              ctx.lineWidth=4; ctx.strokeStyle='rgba(0,0,0,0.95)'; ctx.lineJoin='round';
              ctx.strokeText(String(n),0,0);
              ctx.fillStyle='#ffffff'; ctx.fillText(String(n),0,0);
              ctx.restore();
          }

          /* Centre hub — topmost layer */
          ctx.beginPath(); ctx.arc(CX,CY,20,0,Math.PI*2);
          var g=ctx.createRadialGradient(CX,CY,2,CX,CY,20);
          g.addColorStop(0,'#f5e07a'); g.addColorStop(1,'#b8962e');
          ctx.fillStyle=g; ctx.fill();
          ctx.strokeStyle='#7a5c1a'; ctx.lineWidth=2; ctx.stroke();
      }

      function animateSpin(winningNumber, onDone) {
          var canvas = document.getElementById('g24-wheel-canvas');
          var ball   = document.getElementById('g24-ball');
          if (!canvas||!ball){onDone();return;}

          var idx = WHEEL_NUMS.indexOf(winningNumber);
          /*
           * Align CENTRE of winning segment to top pointer (−90°).
           * Midpoint of segment k is at:  k*SLICE_DEG − 90 + SLICE_DEG/2  degrees.
           * We need that angle == 0 (top) after rotation, i.e.:
           *   rotation = −( idx*SLICE_DEG − 90 + SLICE_DEG/2 )  (mod 360)
           *            =   90 − idx*SLICE_DEG − SLICE_DEG/2     (mod 360)
           */
          /* Целевой угол канваса [0,360): R ≡ -(idx+0.5)*SLICE_DEG (mod 360)
             * Учитываем currentWheelDeg — дельта от текущего до цели. */
            var startDeg    = currentWheelDeg;
            var targetFinal = ((-(idx + 0.5) * SLICE_DEG) % 360 + 360) % 360;
            var startNorm   = ((startDeg % 360) + 360) % 360;
            var delta       = (targetFinal - startNorm + 360) % 360;
            if (delta < 90) delta += 360;
            var wheelTotal  = delta + 5 * 360;

            var ballTotal = 10 * 2 * Math.PI;
          var duration  = 5500, startTime = null;
          ball.style.display='block';

          function easeOut(t){return 1-Math.pow(1-t,3.5);}

          function frame(ts){
              if(!startTime)startTime=ts;
              var elapsed=ts-startTime, progress=Math.min(elapsed/duration,1), eased=easeOut(progress);
              canvas.style.transform='rotate('+(startDeg+wheelTotal*eased)+'deg)';

              var ballAngle  = -Math.PI/2 - ballTotal*eased;
              var rp         = progress<0.7 ? 0 : (progress-0.7)/0.3;
              var ballRadius = OUTER_R+10-(OUTER_R+10-(INNER_R+8))*easeOut(rp);
              var wobble     = (1-eased)*4*Math.sin(elapsed/80);
              ball.style.left=(CX+ballRadius*Math.cos(ballAngle)-BALL_R+wobble)+'px';
              ball.style.top =(CY+ballRadius*Math.sin(ballAngle)-BALL_R)+'px';

              if(progress<1){requestAnimationFrame(frame);}
              else{
                  currentWheelDeg = ((startDeg + wheelTotal) % 360 + 360) % 360;
                  var pr=INNER_R+(OUTER_R-INNER_R)*0.5;
                  ball.style.left=(CX+pr*Math.cos(-Math.PI/2)-BALL_R)+'px';
                  ball.style.top =(CY+pr*Math.sin(-Math.PI/2)-BALL_R)+'px';
                  onDone();
              }
          }
          requestAnimationFrame(frame);
      }

      function fmtBalance(val){return parseFloat(val).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,' ');}
      function colorLabel(num){if(num===0)return 'ЗЕЛЁНОЕ (0)';return RED_NUMS.indexOf(num)!==-1?'КРАСНОЕ':'ЧЁРНОЕ';}
      function colorHex(num){if(num===0)return '#1b7b4b';return RED_NUMS.indexOf(num)!==-1?'#e74c3c':'#aaa';}
      function updateBalance(val){
          var str=fmtBalance(val);
          $('#g24-balance').text(str).addClass('g24-balance-pulse');
          $('#g24-widget-balance').text(str+' BYN');
          $('#g24-modal-balance-val').text(str);
          g24Casino.balance=val;
          setTimeout(function(){$('#g24-balance').removeClass('g24-balance-pulse');},600);
      }
      function showResult(num,won,payout){
          $('#g24-winning-number').text(num).css('color',colorHex(num));
          $('#g24-winning-label').text(colorLabel(num));
          if(won)$('#g24-result-message').text('🎉 ВЫИГРЫШ +'+parseFloat(payout).toFixed(2)+' BYN').attr('class','g24-result-message g24-result-win');
          else   $('#g24-result-message').text('😔 ПРОИГРЫШ — попробуйте ещё!').attr('class','g24-result-message g24-result-loss');
      }
      function addHistoryRow(data){
          var $body=$('#g24-history-body');
          var now=new Date();
          var time=('0'+now.getDate()).slice(-2)+'.'+('0'+(now.getMonth()+1)).slice(-2)+' '+('0'+now.getHours()).slice(-2)+':'+('0'+now.getMinutes()).slice(-2);
          var rc=data.won?'g24-win':'g24-loss', rt=data.won?'Выигрыш':'Проигрыш';
          var pay=data.won?'+'+parseFloat(data.payout).toFixed(2)+' BYN':'—';
          var bet=parseFloat($('#g24-bet-amount').val()).toFixed(2);
          var $row=$('<tr class="'+rc+'"><td>'+time+'</td><td>'+bet+' BYN</td><td>'+selectedBetType+'/'+selectedBetValue+'</td><td><strong>'+data.winning_number+'</strong></td><td class="'+rc+'">'+rt+'</td><td>'+pay+'</td></tr>');
          if($body.find('.g24-no-data').length)$body.empty();
          $body.prepend($row);
          if($body.find('tr').length>10)$body.find('tr:last').remove();
      }
      function updateSelectedBetDisplay(){
          var labels={'color-red':'Красное x2','color-black':'Чёрное x2','parity-odd':'Нечётное x2','parity-even':'Чётное x2','half-low':'1–18 x2','half-high':'19–36 x2','dozen-1':'Дюжина 1–12 x3','dozen-2':'Дюжина 13–24 x3','dozen-3':'Дюжина 25–36 x3','column-1':'Колонка 1 x3','column-2':'Колонка 2 x3','column-3':'Колонка 3 x3'};
          var $el=$('#g24-selected-bet');
          if(!selectedBetType){$el.html('<span>Ставка не выбрана</span>').removeClass('g24-has-bet');return;}
          var key=selectedBetType+'-'+selectedBetValue;
          var label=labels[key]||(selectedBetType==='number'?'Число '+selectedBetValue+' x36':key);
          $el.html('<strong>Ваша ставка:</strong> '+label).addClass('g24-has-bet');
      }
      function checkSpinReady(){$('#g24-spin-btn').prop('disabled',!(!isSpinning&&selectedBetType&&parseFloat($('#g24-bet-amount').val())>0));}

      $(document).ready(function(){
          drawWheel();
          var ball=document.getElementById('g24-ball'); if(ball)ball.style.display='none';

          $(document).on('click','.g24-tab',function(){var t=$(this).data('tab');$('.g24-tab').removeClass('active');$(this).addClass('active');$('.g24-tab-content').removeClass('active');$('#g24-tab-'+t).addClass('active');});
          $(document).on('click','.g24-bet-quick',function(){var a=parseFloat($(this).data('amount')),b=parseFloat(g24Casino.balance||0);if(!isNaN(a))$('#g24-bet-amount').val(Math.min(a,b));checkSpinReady();});
          $('#g24-bet-max').on('click',function(){$('#g24-bet-amount').val(Math.min(parseFloat(g24Casino.balance||0),parseFloat(g24Casino.maxBet||1000)).toFixed(2));checkSpinReady();});
          $('#g24-bet-amount').on('input change',checkSpinReady);
          $(document).on('click','.g24-bet-btn,.g24-num-btn',function(){selectedBetType=$(this).data('type');selectedBetValue=String($(this).data('value'));$('.g24-bet-btn,.g24-num-btn').removeClass('g24-selected');$(this).addClass('g24-selected');updateSelectedBetDisplay();checkSpinReady();});

          $('#g24-spin-btn').on('click',function(){
              if(isSpinning||!selectedBetType)return;
              var betAmt=parseFloat($('#g24-bet-amount').val());
              if(!betAmt||betAmt<=0){alert('Введите сумму ставки');return;}
              isSpinning=true;$('#g24-spin-btn').prop('disabled',true);$('#g24-spin-btn .g24-spin-text').hide();$('#g24-spin-btn .g24-spin-loading').show();$('#g24-result-message').text('').attr('class','g24-result-message');
              $.ajax({url:g24Casino.ajaxUrl,type:'POST',data:{action:'g24_spin',nonce:g24Casino.nonce,bet_amount:betAmt,bet_type:selectedBetType,bet_value:selectedBetValue},
                  success:function(resp){
                      if(!resp.success){alert(resp.data.message||'Ошибка');isSpinning=false;$('#g24-spin-btn').prop('disabled',false);$('#g24-spin-btn .g24-spin-text').show();$('#g24-spin-btn .g24-spin-loading').hide();return;}
                      animateSpin(resp.data.winning_number,function(){showResult(resp.data.winning_number,resp.data.won,resp.data.payout);updateBalance(resp.data.new_balance);addHistoryRow(resp.data);isSpinning=false;$('#g24-spin-btn .g24-spin-text').show();$('#g24-spin-btn .g24-spin-loading').hide();checkSpinReady();});
                  },
                  error:function(){alert('Ошибка соединения.');isSpinning=false;$('#g24-spin-btn').prop('disabled',false);$('#g24-spin-btn .g24-spin-text').show();$('#g24-spin-btn .g24-spin-loading').hide();}
              });
          });

          $('#g24-open-withdraw').on('click',function(){$('#g24-modal-overlay').fadeIn(200);$('#g24-wd-msg').hide().text('');});
          function closeModal(){$('#g24-modal-overlay').fadeOut(200);}
          $('#g24-modal-close,#g24-modal-close2').on('click',closeModal);
          $('#g24-modal-overlay').on('click',function(e){if($(e.target).is('#g24-modal-overlay'))closeModal();});
          $('#g24-wd-submit').on('click',function(){
              var amount=parseFloat($('#g24-wd-amount').val()),card=$.trim($('#g24-wd-card').val()),$msg=$('#g24-wd-msg');
              if(!amount||amount<=0){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Введите сумму');return;}
              if(!card){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Введите реквизиты карты');return;}
              var $btn=$('#g24-wd-submit').prop('disabled',true).text('Отправка...');
              $.ajax({url:g24Casino.ajaxUrl,type:'POST',data:{action:'g24_request_withdrawal',nonce:g24Casino.nonce,amount:amount,card_details:card},
                  success:function(resp){if(resp.success){$msg.show().attr('class','g24-wd-msg g24-wd-ok').text('✅ Заявка отправлена! Ожидайте выплаты.');updateBalance(resp.data.new_balance);$('#g24-wd-amount,#g24-wd-card').val('');setTimeout(closeModal,2500);}else{$msg.show().attr('class','g24-wd-msg g24-wd-error').text(resp.data.message||'Ошибка');}},
                  error:function(){$msg.show().attr('class','g24-wd-msg g24-wd-error').text('Ошибка соединения');},
                  complete:function(){$btn.prop('disabled',false).text('Отправить заявку');}
              });
          });
      });
  })(jQuery);
  