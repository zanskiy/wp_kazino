/* GOROD24 Casino Admin JS v3.0 */
(function($) {
    'use strict';

    $(document).ready(function() {

        /* ── Balance page ─────────────────────────────────────────────── */
        $('#g24-admin-user').on('change', function() {
            var bal = $(this).find(':selected').data('balance');
            if ($(this).val()) {
                $('#g24-cur-bal-row').show();
                $('#g24-cur-bal').text(parseFloat(bal||0).toFixed(2) + ' BYN');
            } else {
                $('#g24-cur-bal-row').hide();
            }
        });

        $(document).on('click', '.g24-quick-amt', function() {
            $('#g24-admin-amount').val($(this).data('amount'));
        });

        $(document).on('click', '.g24-inline-add', function() {
            $('#g24-admin-user').val($(this).data('user-id')).trigger('change');
            $('html,body').animate({scrollTop:0},300);
            setTimeout(function(){ $('#g24-admin-amount').focus(); }, 350);
        });

        function showMsg(text, type) {
            $('#g24-admin-msg').attr('class','g24-admin-msg '+type).text(text).show();
            setTimeout(function(){ $('#g24-admin-msg').fadeOut(); }, 4000);
        }

        function doFunds(action) {
            var uid    = $('#g24-admin-user').val();
            var amount = $('#g24-admin-amount').val();
            var desc   = $('#g24-admin-desc').val();
            if (!uid)   { showMsg('Выберите пользователя','error'); return; }
            if (!amount || parseFloat(amount)<=0) { showMsg('Введите сумму','error'); return; }
            var $btn = action==='g24_admin_add_funds' ? $('#g24-btn-add') : $('#g24-btn-deduct');
            $btn.prop('disabled',true);
            $.post(g24Admin.ajaxUrl, {action:action,nonce:g24Admin.nonce,target_user_id:uid,amount:amount,description:desc}, function(resp) {
                if (resp.success) {
                    showMsg(resp.data.message,'success');
                    $('#g24-cur-bal').text(parseFloat(resp.data.new_balance).toFixed(2)+' BYN');
                    $('#g24-admin-user option[value="'+uid+'"]').data('balance',resp.data.new_balance);
                    $('.g24-inline-add[data-user-id="'+uid+'"]').closest('tr').find('td:eq(4) strong').text(parseFloat(resp.data.new_balance).toFixed(2));
                } else {
                    showMsg(resp.data.message||'Ошибка','error');
                }
            }).always(function(){ $btn.prop('disabled',false); });
        }

        $('#g24-btn-add').on('click', function(){ doFunds('g24_admin_add_funds'); });
        $('#g24-btn-deduct').on('click', function(){
            if (confirm('Вы уверены, что хотите списать средства?')) doFunds('g24_admin_deduct_funds');
        });

        /* ── Withdrawals page ─────────────────────────────────────────── */
        $(document).on('click', '.g24-approve-btn', function() {
            var $wrap = $(this).closest('.g24-wd-actions');
            var id    = $wrap.data('id');
            var note  = $wrap.find('.g24-note-input').val();
            if (!confirm('Подтвердить выплату #'+id+'?')) return;
            doWithdrawal('g24_admin_approve_withdrawal', id, note, $(this));
        });

        $(document).on('click', '.g24-reject-btn', function() {
            var $wrap = $(this).closest('.g24-wd-actions');
            var id    = $wrap.data('id');
            var note  = $wrap.find('.g24-note-input').val();
            if (!note) { alert('Укажите причину отклонения в поле примечания'); return; }
            if (!confirm('Отклонить заявку #'+id+'? Средства вернутся на баланс пользователя.')) return;
            doWithdrawal('g24_admin_reject_withdrawal', id, note, $(this));
        });

        function doWithdrawal(action, id, note, $btn) {
            $btn.prop('disabled',true).text('...');
            $.post(g24Admin.ajaxUrl, {action:action,nonce:g24Admin.nonce,withdrawal_id:id,note:note}, function(resp) {
                if (resp.success) {
                    var $row = $('#g24-wd-row-'+id);
                    var html = action==='g24_admin_approve_withdrawal'
                        ? '<span class="g24-badge g24-badge-green">✅ Выплачено</span>'
                        : '<span class="g24-badge g24-badge-red">❌ Отклонено</span>';
                    if (note) html += '<br><small style="color:#aaa">'+note+'</small>';
                    $row.find('td:nth-child(7)').html(html);
                    $row.find('.g24-wd-actions').html('<span style="color:#aaa;font-size:12px;">Обработано</span>');
                    $row.css('opacity','0.6');
                } else {
                    alert(resp.data.message||'Ошибка');
                    $btn.prop('disabled',false).text($btn.hasClass('g24-approve-btn')?'✅ Выплачено':'❌ Отклонить');
                }
            });
        }

        /* ── Deposits page ────────────────────────────────────────────── */
        $(document).on('click', '.g24-dep-approve-btn', function() {
            var $wrap = $(this).closest('.g24-dep-actions');
            var id    = $wrap.data('id');
            var note  = $wrap.find('.g24-note-input').val();
            if (!confirm('Зачислить средства по заявке #'+id+'?')) return;
            doDeposit('g24_admin_approve_deposit', id, note, $(this));
        });

        $(document).on('click', '.g24-dep-reject-btn', function() {
            var $wrap = $(this).closest('.g24-dep-actions');
            var id    = $wrap.data('id');
            var note  = $wrap.find('.g24-note-input').val();
            if (!note) { alert('Укажите причину отклонения'); return; }
            if (!confirm('Отклонить заявку на пополнение #'+id+'?')) return;
            doDeposit('g24_admin_reject_deposit', id, note, $(this));
        });

        function doDeposit(action, id, note, $btn) {
            $btn.prop('disabled',true).text('...');
            $.post(g24Admin.ajaxUrl, {action:action,nonce:g24Admin.nonce,deposit_id:id,note:note}, function(resp) {
                if (resp.success) {
                    var $row = $('#g24-dep-row-'+id);
                    var html = action==='g24_admin_approve_deposit'
                        ? '<span class="g24-badge g24-badge-green">✅ Зачислено</span>'
                        : '<span class="g24-badge g24-badge-red">❌ Отклонено</span>';
                    if (note) html += '<br><small style="color:#aaa">'+note+'</small>';
                    $row.find('td:nth-child(7)').html(html);
                    $row.find('.g24-dep-actions').html('<span style="color:#aaa;font-size:12px;">Обработано</span>');
                    $row.css('opacity','0.6');
                } else {
                    alert(resp.data.message||'Ошибка');
                    $btn.prop('disabled',false).text($btn.hasClass('g24-dep-approve-btn')?'✅ Зачислить':'❌ Отклонить');
                }
            });
        }

        /* ── Settings page ────────────────────────────────────────────── */
        var $slider = $('#g24s-win-rate');
        var $val    = $('#g24s-win-rate-val');
        if ($slider.length) {
            $slider.on('input', function() {
                $val.text($(this).val()+'%');
                $('#prev-win').text($(this).val());
                $('#prev-edge').text(100-parseInt($(this).val()));
            });
        }

        $('#g24-save-settings').on('click', function() {
            var $btn = $(this).prop('disabled',true).text('Сохранение...');
            $.post(g24Admin.ajaxUrl, {
                action:           'g24_admin_save_settings',
                nonce:            g24Admin.nonce,
                win_rate:         $('#g24s-win-rate').val(),
                min_bet:          $('#g24s-min-bet').val(),
                max_bet:          $('#g24s-max-bet').val(),
                card_info:        $('#g24s-card-info').val(),
                deposit_info:     $('#g24s-deposit-info').val(),
                play_page_url:    $('#g24s-play-url').val(),
                profit_protection: $('#g24s-protection').is(':checked') ? 1 : 0,
            }, function(resp) {
                var $msg = $('#g24-settings-msg');
                if (resp.success) {
                    $msg.attr('class','g24-admin-msg success').text('✅ '+resp.data.message).show();
                } else {
                    $msg.attr('class','g24-admin-msg error').text('❌ '+(resp.data.message||'Ошибка')).show();
                }
                setTimeout(function(){ $msg.fadeOut(); }, 3500);
            }).always(function(){ $btn.prop('disabled',false).text('💾 Сохранить настройки'); });
        });
    });

})(jQuery);
