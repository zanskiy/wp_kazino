/*!
   * GOROD24 Casino Embed Widget v1.0
   * Разместите на любом сайте одной строкой:
   * <script src="https://ВАШ-САЙТ/wp-content/plugins/gorod24-casino/assets/js/embed.js"
   *         data-site="https://ВАШ-САЙТ"
   *         data-color="#d4af37"
   *         data-label="🎰 Играть в казино"
   *         data-position="bottom-right"></script>
   */
  (function() {
      'use strict';

      /* ── Read config from <script> tag attributes ── */
      var scripts = document.querySelectorAll('script[src*="gorod24-casino"][src*="embed.js"]');
      var tag     = scripts[scripts.length - 1];
      var SITE    = (tag.getAttribute('data-site') || '').replace(/\/+$/, '');
      var COLOR   = tag.getAttribute('data-color')    || '#d4af37';
      var LABEL   = tag.getAttribute('data-label')    || '🎰 Казино';
      var POS     = tag.getAttribute('data-position') || 'bottom-right';

      if (!SITE) { console.warn('[G24 Casino] Укажите data-site="https://ваш-сайт"'); return; }

      var CASINO_URL = SITE + '/?g24_embed=1';

      /* ── Inject styles ── */
      var style = document.createElement('style');
      style.textContent = [
          '.g24emb-btn{position:fixed;z-index:2147483646;cursor:pointer;border:none;outline:none;',
          'background:linear-gradient(135deg,'+COLOR+' 0%,#8a6a0a 100%);',
          'color:#000;font-family:sans-serif;font-size:15px;font-weight:800;',
          'padding:14px 22px;border-radius:50px;',
          'box-shadow:0 4px 22px rgba(0,0,0,.45),0 0 0 3px '+COLOR+'44;',
          'transition:transform .2s,box-shadow .2s;letter-spacing:.3px;',
          'animation:g24emb-pulse 2.5s infinite;}',

          '@keyframes g24emb-pulse{',
          '0%,100%{box-shadow:0 4px 22px rgba(0,0,0,.45),0 0 0 3px '+COLOR+'44;}',
          '50%{box-shadow:0 4px 28px rgba(0,0,0,.55),0 0 0 8px '+COLOR+'22;}}',

          '.g24emb-btn:hover{transform:translateY(-3px) scale(1.04);',
          'box-shadow:0 8px 30px rgba(0,0,0,.5),0 0 0 5px '+COLOR+'66;}',

          /* Position variants */
          '.g24emb-btn.bottom-right{bottom:24px;right:24px;}',
          '.g24emb-btn.bottom-left{bottom:24px;left:24px;}',
          '.g24emb-btn.top-right{top:24px;right:24px;}',
          '.g24emb-btn.top-left{top:24px;left:24px;}',

          /* Overlay */
          '.g24emb-overlay{position:fixed;inset:0;z-index:2147483647;',
          'background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;',
          'opacity:0;pointer-events:none;transition:opacity .25s;}',
          '.g24emb-overlay.open{opacity:1;pointer-events:all;}',

          '.g24emb-box{position:relative;width:min(96vw,980px);height:min(92vh,720px);',
          'border-radius:14px;overflow:hidden;',
          'box-shadow:0 20px 70px rgba(0,0,0,.75),0 0 0 2px '+COLOR+';}',

          '.g24emb-close{position:absolute;top:10px;right:12px;z-index:10;',
          'background:rgba(0,0,0,.6);border:1px solid #555;color:#fff;',
          'width:32px;height:32px;border-radius:50%;font-size:17px;',
          'cursor:pointer;display:flex;align-items:center;justify-content:center;',
          'transition:background .2s;}',
          '.g24emb-close:hover{background:rgba(180,0,0,.7);}',

          '.g24emb-iframe{width:100%;height:100%;border:none;display:block;background:#0d1117;}',

          '.g24emb-loader{position:absolute;inset:0;display:flex;flex-direction:column;',
          'align-items:center;justify-content:center;background:#0d1117;color:#d4af37;',
          'font-family:sans-serif;font-size:16px;font-weight:700;gap:14px;}',
          '.g24emb-spinner{width:44px;height:44px;border:4px solid #333;',
          'border-top:4px solid '+COLOR+';border-radius:50%;',
          'animation:g24emb-spin .8s linear infinite;}',
          '@keyframes g24emb-spin{to{transform:rotate(360deg)}}'
      ].join('');
      document.head.appendChild(style);

      /* ── Create floating button ── */
      var btn = document.createElement('button');
      btn.className = 'g24emb-btn ' + POS;
      btn.textContent = LABEL;
      document.body.appendChild(btn);

      /* ── Create overlay modal ── */
      var overlay = document.createElement('div');
      overlay.className = 'g24emb-overlay';
      overlay.innerHTML =
          '<div class="g24emb-box">' +
              '<button class="g24emb-close" title="Закрыть">✕</button>' +
              '<div class="g24emb-loader" id="g24emb-loader">' +
                  '<div class="g24emb-spinner"></div>' +
                  '<span>Загрузка казино…</span>' +
              '</div>' +
              '<iframe class="g24emb-iframe" id="g24emb-frame" allow="autoplay" loading="lazy"></iframe>' +
          '</div>';
      document.body.appendChild(overlay);

      var frame  = overlay.querySelector('#g24emb-frame');
      var loader = overlay.querySelector('#g24emb-loader');
      var close  = overlay.querySelector('.g24emb-close');
      var loaded = false;

      function openCasino() {
          overlay.classList.add('open');
          document.body.style.overflow = 'hidden';
          if (!loaded) {
              frame.src = CASINO_URL;
              frame.onload = function() { loader.style.display = 'none'; };
              loaded = true;
          }
      }

      function closeCasino() {
          overlay.classList.remove('open');
          document.body.style.overflow = '';
      }

      btn.addEventListener('click', openCasino);
      close.addEventListener('click', closeCasino);
      overlay.addEventListener('click', function(e) {
          if (e.target === overlay) closeCasino();
      });
      document.addEventListener('keydown', function(e) {
          if (e.key === 'Escape') closeCasino();
      });

  })();
  